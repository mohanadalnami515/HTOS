import discord
import asyncio
from io import BytesIO
from discord import Option
from discord.ext import commands
from utils.workspace import make_workspace
from utils.helpers import error_handling
from utils.constants import logger, SYS_FILE_MAX, BASE_ERROR_MSG, SAVEBLOCKS_MAX, SAVEBLOCKS_MIN, COMMAND_COOLDOWN, EMBED_FIELD_VALUE_LIMIT
from utils.embeds import loadSFO_emb, finished_emb, paramEmb
from utils.orbis import SFOContext, is_valid_savedirname, check_titleid, checkid
from utils.instance_lock import INSTANCE_LOCK_global
from utils.exceptions import WorkspaceError, OrbisError

class SFOEditor(SFOContext):
    """Discord utilities to parse and patch param.sfo."""
    def __init__(self, sfo_data: bytearray) -> None:
        super().__init__()
        self.sfo_data = sfo_data

    def read(self) -> None:
        self.sfo_read(self.sfo_data)
        self.param_data = self.sfo_get_param_data()

    def write(self) -> None:
        self.sfo_data = self.sfo_write()

    def dict_embed(self) -> list[discord.Embed]:
        embeds = []
        p_data = self.param_data.copy()
        for param in p_data:
            emb = paramEmb.copy()
            if param["key"] == "PARAMS":
                param["converted_value"] = param["converted_value"].rstrip("0")
            for key, val in param.items():
                if key == "value":
                    continue
                if len(str(val)) > EMBED_FIELD_VALUE_LIMIT:
                    raise ValueError("One of the values is too large to show!")
                emb.add_field(
                    name=key.upper(),
                    value=val,
                    inline=True
                )
            embeds.append(emb)
        return embeds

class SFO(commands.Cog):
    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot

    sfo_group = discord.SlashCommandGroup("sfo")

    @sfo_group.command(description="Parse a param.sfo file to obtain information about the save.")
    @commands.cooldown(1, COMMAND_COOLDOWN, commands.BucketType.user)
    async def read(self, ctx: discord.ApplicationContext, sfo: discord.Attachment) -> None:
        workspace_folders = []
        try: await make_workspace(ctx, workspace_folders, ctx.channel_id, skip_gd_check=True)
        except (WorkspaceError, discord.HTTPException): return

        try:
            await ctx.respond(embed=loadSFO_emb)
        except discord.HTTPException as e:
            logger.info(f"Error while responding to interaction: {e}", exc_info=True)
            await INSTANCE_LOCK_global.release(ctx.author.id)
            return

        if sfo.size > SYS_FILE_MAX:
            e = "File size is too large!"
            await error_handling(ctx, e, workspace_folders, None, None, None)
            await INSTANCE_LOCK_global.release(ctx.author.id)
            return

        sfo_data = bytearray(await sfo.read())

        try:
            sfo_ctx = SFOEditor(sfo_data)
            sfo_ctx.read()
            param_embeds = sfo_ctx.dict_embed()
            for emb in param_embeds:
                await asyncio.sleep(1)
                await ctx.send(embed=emb)
            await ctx.edit(embed=finished_emb)
        except (OrbisError, ValueError) as e:
            await error_handling(ctx, e, workspace_folders, None, None, None)
            logger.info(f"{e} - {ctx.user.name} - (expected)", exc_info=True)
            await INSTANCE_LOCK_global.release(ctx.author.id)
            return
        except Exception as e:
            await error_handling(ctx, BASE_ERROR_MSG, workspace_folders, None, None, None)
            logger.exception(f"{e} - {ctx.user.name} - (unexpected)")
            await INSTANCE_LOCK_global.release(ctx.author.id)
            return
        await INSTANCE_LOCK_global.release(ctx.author.id)

    @sfo_group.command(description="Patch parameters in a param.sfo file to modify the save.")
    @commands.cooldown(1, COMMAND_COOLDOWN, commands.BucketType.user)
    async def write(
              self,
              ctx: discord.ApplicationContext,
              sfo: discord.Attachment,
              account_id: Option(str, description="uint64 (hexadecimal)", default="", max_length=2 + 16),
              attribute: Option(int, description="uint32", default="", min_value=0, max_value=0xFF_FF_FF_FF),
              category: Option(str, description="utf-8", default=""),
              detail: Option(str, description="utf-8", default=""),
              format: Option(str, description="utf-8", default=""),
              maintitle: Option(str, description="utf-8", default=""),
              params: Option(str, description="byte string (hexadecimal)", default=""),
              savedata_blocks: Option(int, description="uint64", default="", min_value=SAVEBLOCKS_MIN, max_value=SAVEBLOCKS_MAX),
              savedata_directory: Option(str, description="utf-8", default=""),
              savedata_list_param: Option(int, description="uint32", default="", min_value=0, max_value=0xFF_FF_FF_FF),
              subtitle: Option(str, description="utf-8", default=""),
              title_id: Option(str, description="utf-8", default="")
            ) -> None:

        parameters = {
            "ACCOUNT_ID": account_id,
            "ATTRIBUTE": attribute,
            "CATEGORY": category,
            "DETAIL": detail,
            "FORMAT": format,
            "MAINTITLE": maintitle,
            "PARAMS": params,
            "SAVEDATA_BLOCKS": savedata_blocks,
            "SAVEDATA_DIRECTORY": savedata_directory,
            "SAVEDATA_LIST_PARAM": savedata_list_param,
            "SUBTITLE": subtitle,
            "TITLE_ID": title_id
        }
        workspace_folders = []
        try: await make_workspace(ctx, workspace_folders, ctx.channel_id, skip_gd_check=True)
        except (WorkspaceError, discord.HTTPException): return

        try:
            await ctx.respond(embed=loadSFO_emb)
        except discord.HTTPException as e:
            logger.info(f"Error while responding to interaction: {e}", exc_info=True)
            await INSTANCE_LOCK_global.release(ctx.author.id)
            return

        e = []
        if account_id:
            if account_id.lower().startswith("0x"):
                accid = account_id[2:]
            else:
                accid = account_id
            if not checkid(accid):
                e.append("account ID")
        if savedata_directory:
            if not is_valid_savedirname(savedata_directory):
                e.append("savedata directory")
        if title_id:
            if not check_titleid(title_id):
                e.append("title ID")
        if e:
            e = ", ".join(e)
            e = f"Invalid {e}!"
            await error_handling(ctx, e, workspace_folders, None, None, None)
            await INSTANCE_LOCK_global.release(ctx.author.id)
            return

        if sfo.size > SYS_FILE_MAX:
            e = "File size is too large!"
            await error_handling(ctx, e, workspace_folders, None, None, None)
            await INSTANCE_LOCK_global.release(ctx.author.id)
            return

        sfo_data = bytearray(await sfo.read())

        try:
            sfo_ctx = SFOEditor(sfo_data)
            sfo_ctx.read()
            for key, val in parameters.items():
                if not val:
                    continue
                sfo_ctx.sfo_patch_parameter(key, val)
            sfo_ctx.write()

            await ctx.edit(embed=finished_emb)
            await ctx.respond(file=discord.File(BytesIO(sfo_ctx.sfo_data), filename=sfo.filename))
        except OrbisError as e:
            await error_handling(ctx, e, workspace_folders, None, None, None)
            logger.info(f"{e} - {ctx.user.name} - (expected)", exc_info=True)
            await INSTANCE_LOCK_global.release(ctx.author.id)
            return
        except Exception as e:
            if isinstance(e, ValueError):
                err = "Invalid value inputted!"
            else:
                err = BASE_ERROR_MSG
            await error_handling(ctx, err, workspace_folders, None, None, None)
            logger.exception(f"{e} - {ctx.user.name} - (unexpected)")
            await INSTANCE_LOCK_global.release(ctx.author.id)
            return
        await INSTANCE_LOCK_global.release(ctx.author.id)

def setup(bot: commands.Bot) -> None:
    bot.add_cog(SFO(bot))

