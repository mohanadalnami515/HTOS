from __future__ import annotations

import os
import hashlib
import hmac
import aiofiles
import aiofiles.os
import crc32c
import mmh3
import zlib
import anycrc
from types import TracebackType

from data.crypto.algorithms.jhash.lookup2 import JHashLookup2
from data.crypto.algorithms.rijndael.rijndael import Rijndael

from data.crypto.exceptions import CryptoError

from aiofiles.threadpool.binary import AsyncBufferedReader
from Crypto.Cipher import AES, Blowfish, DES3
from typing import Literal, Any, Self

from utils.constants import SCE_SYS_NAME, RANDOMSTRING_LENGTH
# from utils.constants import SAVESIZE_MAX
from utils.conversions import mb_to_bytes, bytes_to_mb
from utils.type_helpers import Cint, uint8, uint32, uint64
from utils.extras import generate_random_string

class CustomCryptoCtx:
    def __init__(
        self,
        obj: Any,
        attr: Any | None = None
    ) -> None:
        self.obj = obj
        self.attr = attr

class CustomCrypto:
    CHUNKSIZE = mb_to_bytes(1)
    SAVESIZE_MAX = mb_to_bytes(25) # some implementations are in pure python, can be too slow
    AES = AES
    Blowfish = Blowfish
    DES3 = DES3
    zlib = zlib
    crc32c = crc32c
    mmh3 = mmh3
    hashlib = hashlib
    hmac = hmac
    anycrc = anycrc
    JHashLookup2 = JHashLookup2
    Rijndael = Rijndael

    def __init__(
        self,
        filepath: str,
        in_place: bool = True
    ) -> None:
        self.filepath = filepath
        self.temp_filepath = None
        self.in_place = in_place
        self.r_stream: AsyncBufferedReader | None = None
        self.w_stream: AsyncBufferedReader | None = None

        self.chunk = None
        self.size = None
        self.chunk_start = 0
        self.chunk_end = 0

        self.ctx_container: dict[int, CustomCryptoCtx] = {}
        self.i = 0

    async def __aenter__(self) -> Self:
        self.r_stream = await aiofiles.open(self.filepath, "r+b")

        if self.in_place:
            self.w_stream = self.r_stream
        else:
            rand_str = generate_random_string(RANDOMSTRING_LENGTH)
            self.temp_filepath = os.path.join(os.path.dirname(self.filepath), rand_str)
            self.w_stream = await aiofiles.open(self.temp_filepath, "w+b")
        await self.get_size()
        await self.r_stream.seek(0)
        return self

    async def __aexit__(self, _: type[BaseException] | None, __: BaseException | None, ___: TracebackType | None) -> None:
        await self.r_stream.close()
        if self.r_stream is not self.w_stream:
            await self.w_stream.close()
            await aiofiles.os.replace(self.temp_filepath, self.filepath)

    def set_ptr(self, p: int) -> None:
        if not (0 <= p <= self.size):
            raise CryptoError("Invalid")
        self.chunk_end = p
        self.chunk_start = p

    async def get_size(self) -> None:
        self.size = await self.r_stream.seek(0, 2)
        if self.size > self.SAVESIZE_MAX:
            raise CryptoError(
                f"File exceeds the maximum processing size limit ({bytes_to_mb(self.SAVESIZE_MAX)} MB)."
            )

    async def read(self, stop_off: int = -1, backwards: bool = False) -> int:
        if not backwards:
            self.chunk_start = await self.r_stream.seek(self.chunk_end)
            if stop_off < 0:
                self.chunk = bytearray(await self.r_stream.read(self.CHUNKSIZE))
            else:
                if stop_off < self.chunk_start or stop_off > self.size:
                    raise CryptoError("Invalid!")
                r_len = min(self.CHUNKSIZE, stop_off - self.chunk_start)
                self.chunk = bytearray(await self.r_stream.read(r_len))
            self.chunk_end = await self.r_stream.tell()
        else:
            if stop_off < 0:
                s = max(self.chunk_start - self.CHUNKSIZE, 0)
            else:
                if stop_off > self.chunk_start:
                    raise CryptoError("Invalid!")
                s = max(self.chunk_start - self.CHUNKSIZE, stop_off)
            self.chunk_end = self.chunk_start
            self.chunk_start = await self.r_stream.seek(s)
            self.chunk = bytearray(await self.r_stream.read(self.chunk_end - self.chunk_start))
        return len(self.chunk)

    async def write(self) -> int:
        self._prepare_write()
        await self.w_stream.seek(self.chunk_start)
        return await self.w_stream.write(self.chunk)

    async def ext_write(self, off: int, w: bytes | bytearray) -> None:
        assert self.in_place
        if off < 0:
            raise CryptoError("Invalid!")
        if off + len(w) > self.size:
            raise CryptoError("Invalid!")
        await self.w_stream.seek(off)
        await self.w_stream.write(w)

    async def ext_read(self, off: int, n: int) -> bytes:
        assert n <= self.CHUNKSIZE
        await self.r_stream.seek(off)
        r = await self.r_stream.read(n)
        if len(r) != n:
            raise CryptoError("Invalid!")
        return r

    def _get_ctx(self, ctx: int) -> CustomCryptoCtx:
        assert ctx in self.ctx_container
        return self.ctx_container[ctx]

    def delete_ctx(self, ctx: int) -> None:
        self._get_ctx(ctx)
        del self.ctx_container[ctx]

    def _prepare_write(self) -> None:
        assert type(self.chunk) == bytearray

    def _prepare_list_write(self) -> None:
        assert type(self.chunk) == list

    def _prepare_compression(self) -> None:
        assert not self.in_place

    async def trim_trailing_bytes(self, off: int = -1, byte: uint8 = uint8(0, const=True), min_required: int = 1) -> None:
        """
        Start from off and move backward, stop when a byte that differs from the given has been reached.
        Truncate data from the occurence offset if the minimum required amount of bytes moved backward has been reached.
        """
        assert self.in_place

        if off < 0:
            off = self.size - 1
        if not (0 <= off < self.size):
            raise CryptoError("Invalid!")

        pos = off + 1
        stop_off = -1

        while pos > 0:
            r_len = min(pos, self.CHUNKSIZE)
            await self.r_stream.seek(pos - r_len)
            chunk = await self.r_stream.read(r_len)
            chunksize = len(chunk)

            for i in range(chunksize - 1, -1, -1):
                if chunk[i] != byte.value:
                    stop_off = pos - r_len + i
                    break
            if stop_off != -1:
                break
            pos -= r_len

        if stop_off == -1:
            return
        if off - stop_off < min_required:
            return
        self.size = await self.r_stream.truncate(stop_off + 1)

    async def find(self, d: bytes | bytearray, start_off: int = 0, end_off: int = -1) -> int:
        if end_off < 0:
            end_off = self.size
        if not (start_off < end_off <= self.size):
            return -1

        d_len = len(d)
        assert d_len <= self.CHUNKSIZE # bound growth
        target_off = -1
        buf = bytes()
        await self.r_stream.seek(start_off)

        for off in range(start_off, end_off, self.CHUNKSIZE):
            r_len = min(self.CHUNKSIZE, end_off - off)
            chunk = await self.r_stream.read(r_len)
            if not chunk:
                break
            chunk = buf + chunk
            chunk_len = len(chunk)

            if (pos := chunk.find(d)) != -1:
                target_off = off - len(buf) + pos
                break
            if d_len <= chunk_len:
                buf = chunk[-(d_len - 1):]
            else:
                buf = chunk
        return target_off

    async def rfind(self, d: bytes | bytearray, start_off: int = -1, end_off: int = 0) -> int:
        if start_off < 0:
            start_off = self.size
        if not end_off < start_off <= self.size:
            return -1

        d_len = len(d)
        assert d_len <= self.CHUNKSIZE # bound growth
        target_off = -1
        buf = bytes()

        for off in range(start_off, end_off, -self.CHUNKSIZE):
            r_len = min(self.CHUNKSIZE, off - end_off)
            r_start = off - r_len
            await self.r_stream.seek(r_start)
            chunk = await self.r_stream.read(r_len)
            if not chunk:
                break
            chunk = chunk + buf
            chunk_len = len(chunk)

            if (pos := chunk.rfind(d)) != -1:
                target_off = r_start + pos
                break
            if d_len <= chunk_len:
                buf = chunk[:d_len - 1]
            else:
                buf = chunk
        return target_off

    async def copy(self, start_off: int = 0, end_off: int = -1) -> None:
        assert not self.in_place
        if end_off < 0:
            end_off = self.size
        if not start_off < end_off <= self.size:
            raise CryptoError("Invalid!")

        await self.r_stream.seek(start_off)
        for off in range(start_off, end_off, self.CHUNKSIZE):
            r_len = min(self.CHUNKSIZE, end_off - off)
            chunk = await self.r_stream.read(r_len)
            if not chunk:
                break
            if await self.w_stream.tell() + len(chunk) > self.SAVESIZE_MAX:
                raise CryptoError("Invalid!")
            await self.w_stream.write(chunk)

    def bytes_to_u32array(self, byteorder: Literal["little", "big"]) -> None:
        self._prepare_write()
        if not self._trim_chunk(4):
            self.chunk = []
            return

        u32_array = []
        for i in range(0, len(self.chunk), 4):
            u32 = uint32(self.chunk[i:i + 4], endianness=byteorder)
            u32_array.append(u32)
        self.chunk = u32_array

    def array_to_bytearray(self) -> None:
        self._prepare_list_write()
        new_array = bytearray()
        for u in self.chunk:
            u: uint32
            new_array.extend(u.as_bytes)
        self.chunk = new_array

    def ES32(self, chunk: bytearray | None = None) -> None:
        if chunk is None:
            self._prepare_write()
            if not self._trim_chunk(4):
                return
            c = self.chunk
        else:
            assert len(chunk) <= self.CHUNKSIZE
            if len(chunk) % 4 != 0:
                raise CryptoError("Invalid")
            c = chunk

        for i in range(0, len(c), 4):
            c[i:i + 4] = c[i:i + 4][::-1]

    async def fraction_byte(self, byte: uint8 = uint8(0, const=True), div: int = 2) -> bool:
        assert div != 0

        await self.r_stream.seek(0)
        cnt = 0
        bytes_read = 0
        while True:
            chunk = await self.r_stream.read(self.CHUNKSIZE)
            if not chunk:
                break
            bytes_read += len(chunk)

            cnt += chunk.count(byte.value)
            if cnt * div >= self.size:
                return True

            r = self.size - bytes_read
            if (cnt + r) * div < self.size:
                return False
        return cnt * div >= self.size

    NON_PRINTABLE_ASCII_TABLE = bytes([1 if (b <= 31 or b == 127) else 0 for b in range(256)])
    async def fraction_non_printable_chars(self, div: int = 2) -> bool:
        assert div != 0

        await self.r_stream.seek(0)
        cnt = 0
        bytes_read = 0
        while True:
            chunk = await self.r_stream.read(self.CHUNKSIZE)
            if not chunk:
                break
            bytes_read += len(chunk)

            cnt += sum(self.NON_PRINTABLE_ASCII_TABLE[b] for b in chunk)
            if cnt * div >= self.size:
                return True

            r = self.size - bytes_read
            if (cnt + r) * div < self.size:
                return False
        return cnt * div >= self.size

    PRINTABLE_ASCII_TABLE = bytes([1 if (32 <= b <= 126) else 0 for b in range(256)])
    async def fraction_printable_chars(self, div: int = 2) -> bool:
        assert div != 0

        await self.r_stream.seek(0)
        cnt = 0
        bytes_read = 0
        while True:
            chunk = await self.r_stream.read(self.CHUNKSIZE)
            if not chunk:
                break
            bytes_read += len(chunk)

            cnt += sum(self.PRINTABLE_ASCII_TABLE[b] for b in chunk)
            if cnt * div >= self.size:
                return True

            r = self.size - bytes_read
            if (cnt + r) * div < self.size:
                return False
        return cnt * div >= self.size

    def gen_bytes(self, length: int) -> bytes:
        assert 1 <= length <= self.CHUNKSIZE
        b = id(object()) & 0xFF
        return bytes([b] * length)

    async def pkcs7_pad_pre(self, n: int) -> None:
        assert not self.in_place
        assert 1 <= n <= 0xFF

        size_1 = await self.w_stream.seek(0, 2)
        size_2 = size_1 + (n - (size_1 % n))
        if size_2 > self.SAVESIZE_MAX:
            raise CryptoError("Invalid!")
        p = size_2 - size_1
        w = bytes([p] * p)
        await self.w_stream.write(w)

    async def pkcs7_pad_post(self, n: int) -> None:
        assert not self.in_place
        assert 1 <= n <= 0xFF

        size = await self.w_stream.seek(0, 2)
        if size == 0:
            return
        await self.w_stream.seek(size - 1)
        p = (await self.w_stream.read(1))[0]

        if not (1 <= p <= n):
            raise CryptoError("Invalid!")
        s = size - p
        if s < 0:
            raise CryptoError("Invalid!")
        await self.w_stream.seek(s)
        buf = await self.w_stream.read(p)
        if buf != bytes([p] * p):
            raise CryptoError("Invalid!")

        await self.w_stream.truncate(s)

    def _trim_chunk(self, blocksize: int) -> bool:
        """
        Internal method to make `chunk` a multiple of `blocksize`.
        If chunksize is less than blocksize, `False` is returned.
        If chunk is trimmed or does not need to be trimmed, `True` is returned.
        This can be used to prepare `chunk` before processing it in an algorithm that operates on blocks.
        Then if there is some remainder that cannot be processed, the default behavior will be to ignore it.
        """
        assert blocksize > 0

        remainder = self.chunk[len(self.chunk) - (len(self.chunk) % blocksize):]
        if self.chunk == remainder:
            return False
        r = len(remainder)
        if r > 0:
            del self.chunk[-r:]
            self.chunk_end -= r
        return True

    def encrypt(self, ctx: int) -> None:
        self._prepare_write()
        ctx = self._get_ctx(ctx)
        assert hasattr(ctx.obj, "encrypt")
        assert isinstance(ctx.attr, uint8)

        blocksize = ctx.attr.value
        if blocksize == 0:
            ctx.obj.encrypt(self.chunk, self.chunk)
            return
        if not self._trim_chunk(blocksize):
            return

        ctx.obj.encrypt(self.chunk, self.chunk)

    def decrypt(self, ctx: int) -> None:
        self._prepare_write()
        ctx = self._get_ctx(ctx)
        assert hasattr(ctx.obj, "decrypt")
        assert isinstance(ctx.attr, uint8)

        blocksize = ctx.attr.value
        if blocksize == 0:
            ctx.obj.decrypt(self.chunk, self.chunk)
            return
        if not self._trim_chunk(blocksize):
            return

        ctx.obj.decrypt(self.chunk, self.chunk)

    async def compress(self, ctx: int) -> int:
        """No need to call `write` after."""
        self._prepare_write()
        self._prepare_compression()
        ctx = self._get_ctx(ctx)

        if type(ctx.obj) is type(zlib.compressobj()):
            return await self._zlib_compress(ctx.obj)
        else:
            assert 0

    async def compress_post(self, ctx: int) -> int:
        """No need to call `write` after."""
        self._prepare_write()
        self._prepare_compression()
        ctx = self._get_ctx(ctx)

        if type(ctx.obj) is type(zlib.compressobj()):
            return await self._zlib_compress_post(ctx.obj)
        else:
            assert 0

    async def decompress(self, ctx: int) -> int:
        """No need to call `write` after."""
        self._prepare_write()
        self._prepare_compression()
        ctx = self._get_ctx(ctx)

        if type(ctx.obj) is type(zlib.decompressobj()):
            try:
                return await self._zlib_decompress(ctx.obj)
            except zlib.error as e:
                raise CryptoError("Invalid save!") from e
        else:
            assert 0

    async def checksum(self, ctx: int, start_off: int = -1, end_off: int = -1) -> None:
        ctx = self._get_ctx(ctx)

        if start_off < 0 or end_off < 0:
            self._prepare_write()
            if hasattr(ctx.obj, "update"):
                ctx.obj.update(self.chunk)
            elif isinstance(ctx.attr, Cint) and callable(ctx.obj):
                ctx.attr.value = ctx.obj(bytes(self.chunk), ctx.attr.value)
            else:
                assert 0
            return

        if not start_off < end_off <= self.size:
            raise CryptoError("Invalid!")
        await self.r_stream.seek(start_off)

        for off in range(start_off, end_off, self.CHUNKSIZE):
            r_len = min(self.CHUNKSIZE, end_off - off)
            chunk = await self.r_stream.read(r_len)
            if not chunk:
                break

            if hasattr(ctx.obj, "update"):
                ctx.obj.update(chunk)
            elif isinstance(ctx.attr, Cint) and callable(ctx.obj):
                ctx.attr.value = ctx.obj(bytes(chunk), ctx.attr.value)
            else:
                assert 0

    async def write_checksum(self, ctx: int, off: int) -> int:
        ctx = self._get_ctx(ctx)
        if hasattr(ctx.obj, "digest"):
            chks = ctx.obj.digest()
        elif isinstance(ctx.attr, Cint):
            chks = ctx.attr.as_bytes
        else:
            assert 0

        if self.in_place:
            max_size = self.size
        else:
            max_size = self.SAVESIZE_MAX
        if off < 0:
            raise CryptoError("Invalid!")
        if not off + len(chks) <= max_size:
            raise CryptoError("Invalid!")

        await self.w_stream.seek(off)
        return await self.w_stream.write(chks)

    def _create_ctx(self, obj: Any, attr: Any | None = None) -> int:
        x = CustomCryptoCtx(obj, attr)
        self.ctx_container[self.i] = x
        self.i += 1
        assert self.i <= 0xFF
        return self.i - 1

    def create_ctx_aes(self, key: bytes | bytearray, mode: int, **kwargs) -> int:
        cipher = AES.new(key, mode, **kwargs)
        streaming_modes = (
            AES.MODE_CFB, AES.MODE_OFB, AES.MODE_CTR, AES.MODE_OPENPGP,
            AES.MODE_CCM, AES.MODE_EAX, AES.MODE_SIV, AES.MODE_GCM,
            AES.MODE_OCB
        ) # some of these are not properly interfaced
        if mode in streaming_modes:
            bl = 0
        else:
            bl = AES.block_size
        blocksize = uint8(bl, const=True)
        return self._create_ctx(cipher, blocksize)

    def create_ctx_blowfish(self, key: bytes | bytearray, mode: int, **kwargs) -> int:
        cipher = Blowfish.new(key, mode, **kwargs)
        streaming_modes = (
            Blowfish.MODE_CFB, Blowfish.MODE_OFB, Blowfish.MODE_CTR, Blowfish.MODE_OPENPGP,
            Blowfish.MODE_EAX
        ) # some of these are not properly interfaced
        if mode in streaming_modes:
            bl = 0
        else:
            bl = Blowfish.block_size
        blocksize = uint8(bl, const=True)
        return self._create_ctx(cipher, blocksize)

    def create_ctx_des3(self, key: bytes | bytearray, mode: int, **kwargs) -> int:
        cipher = DES3.new(key, mode, **kwargs)
        streaming_modes = (
            DES3.MODE_CFB, DES3.MODE_OFB, DES3.MODE_CTR, DES3.MODE_OPENPGP, DES3.MODE_EAX
        ) # some of these are not properly interfaced
        if mode in streaming_modes:
            bl = 0
        else:
            bl = DES3.block_size
        blocksize = uint8(bl, const=True)
        return self._create_ctx(cipher, blocksize)

    def create_ctx_rijndael(self, key: bytes | bytearray, mode: int, blocksize: int, **kwargs) -> int:
        cipher = Rijndael(key, mode, blocksize, **kwargs)
        if cipher.is_streaming:
            bl = 0
        else:
            bl = blocksize
        blocksize = uint8(bl, const=True)
        return self._create_ctx(cipher, blocksize)

    def create_ctx_zlib_compress(self, wbits: int | None = None) -> int:
        self._prepare_compression()
        if wbits is None:
            obj = zlib.compressobj()
        else:
            obj = zlib.compressobj(wbits=wbits)
        return self._create_ctx(obj)

    def create_ctx_gzip_compress(self) -> int:
        return self.create_ctx_zlib_compress(wbits=zlib.MAX_WBITS | 16)

    def create_ctx_zlib_decompress(self, wbits: int | None = None) -> int:
        self._prepare_compression()
        if wbits is None:
            obj = zlib.decompressobj()
        else:
            obj = zlib.decompressobj(wbits=wbits)
        return self._create_ctx(obj)

    def create_ctx_gzip_decompress(self) -> int:
        return self.create_ctx_zlib_decompress(wbits=zlib.MAX_WBITS | 16)

    def create_ctx_crc32(self, seed: uint32 = uint32(0, "little", const=True)) -> int:
        seed = uint32(seed.value, seed.ENDIANNESS)
        call = zlib.crc32
        return self._create_ctx(call, seed)

    def create_ctx_crc32c(self, seed: uint32 = uint32(0, "little", const=True)) -> int:
        seed = uint32(seed.value, seed.ENDIANNESS)
        call = crc32c.crc32c
        return self._create_ctx(call, seed)

    def create_ctx_crc32_any(
        self,
        poly: int,
        init: int,
        refin: bool,
        refout: bool,
        xorout: int,
        seed: uint32 = uint32(0, "little", const=True),
    ) -> int:
        seed = uint32(seed.value, seed.ENDIANNESS)
        call = anycrc.CRC(width=32, poly=poly, init=init, refin=refin, refout=refout, xorout=xorout).calc
        return self._create_ctx(call, seed)

    def create_ctx_crc64_any(
        self,
        poly: int,
        init: int,
        refin: bool,
        refout: bool,
        xorout: int,
        seed: uint64 = uint64(0, "little", const=True),
    ) -> int:
        seed = uint64(seed.value, seed.ENDIANNESS)
        call = anycrc.CRC(width=64, poly=poly, init=init, refin=refin, refout=refout, xorout=xorout).calc
        return self._create_ctx(call, seed)

    def create_ctx_mmh3_u32(self, seed: uint32 = uint32(0, "little", const=True)) -> int:
        seed = uint32(seed.value, seed.ENDIANNESS)
        update_obj = mmh3.mmh3_32(seed=seed.value)
        return self._create_ctx(update_obj)

    def create_ctx_jhash_lookup2(self, seed: uint32 = uint32(0, "little", const=True)) -> int:
        seed = uint32(seed.value, seed.ENDIANNESS)
        update_obj = JHashLookup2(seed.value, seed.ENDIANNESS)
        return self._create_ctx(update_obj)

    def create_ctx_md5(self) -> int:
        update_obj = hashlib.md5()
        return self._create_ctx(update_obj)

    def create_ctx_sha1(self) -> int:
        update_obj = hashlib.sha1()
        return self._create_ctx(update_obj)

    def create_ctx_hmac(self, key: bytes | bytearray, digestmod: hmac._DigestMod) -> int:
        update_obj = hmac.new(key, digestmod=digestmod)
        return self._create_ctx(update_obj)

    async def _comp_write(self, w: bytes, size: int) -> int:
        l = len(w)
        if size + l > self.SAVESIZE_MAX:
            raise CryptoError("Max size reached while compressing!")
        await self.w_stream.write(w)
        return l

    async def _zlib_compress(self, obj: zlib._Compress) -> int:
        size = await self.w_stream.seek(0, 2)
        l = 0

        comp = obj.compress(self.chunk)
        a = await self._comp_write(comp, size)
        size += a
        l += a

        comp = obj.flush(zlib.Z_SYNC_FLUSH)
        l += await self._comp_write(comp, size) # end; not updating size
        return l

    async def _zlib_compress_post(self, obj: zlib._Compress) -> int:
        size = await self.w_stream.seek(0, 2)
        comp = obj.flush(zlib.Z_FINISH)
        return await self._comp_write(comp, size)

    async def _decomp_write(self, w: bytes, size: int) -> int:
        l = len(w)
        if size + l > self.SAVESIZE_MAX:
            raise CryptoError("Max size reached while decompressing!")
        await self.w_stream.write(w)
        return l

    async def _zlib_decompress(self, obj: zlib._Decompress) -> int:
        if obj.eof:
            return 0

        size = await self.w_stream.seek(0, 2)
        l = 0

        decomp = obj.decompress(self.chunk, self.CHUNKSIZE)
        if obj.unused_data:
            assert obj.eof
            assert not obj.unconsumed_tail
        if decomp:
            a = await self._decomp_write(decomp, size)
            size += a
            l += a

        if obj.unconsumed_tail:
            while True:
                comp = obj.unconsumed_tail
                if not comp:
                    break
                decomp = obj.decompress(comp, self.CHUNKSIZE)
                if obj.unused_data:
                    assert obj.eof
                if not decomp:
                    break
                a = await self._decomp_write(decomp, size)
                size += a
                l += a

        if obj.eof:
            decomp = obj.flush()
            if decomp:
                a = await self._decomp_write(decomp, size)
                # end; not updating size
                l += a

        return l

    @staticmethod
    def is_valid_zlib_header(header: bytes) -> bool:
        ZLIB_HEADERS = frozenset({
            b"\x08\x1D", b"\x08\x5B", b"\x08\x99", b"\x08\xD7",
            b"\x18\x19", b"\x18\x57", b"\x18\x95", b"\x18\xD3",
            b"\x28\x15", b"\x28\x53", b"\x28\x91", b"\x28\xCF",
            b"\x38\x11", b"\x38\x4F", b"\x38\x8D", b"\x38\xCB",
            b"\x48\x0D", b"\x48\x4B", b"\x48\x89", b"\x48\xC7",
            b"\x58\x09", b"\x58\x47", b"\x58\x85", b"\x58\xC3",
            b"\x68\x05", b"\x68\x43", b"\x68\x81", b"\x68\xDE",
            b"\x78\x01", b"\x78\x5E", b"\x78\x9C", b"\x78\xDA",
        })
        return header in ZLIB_HEADERS

    @staticmethod
    def ES32_int(val: int) -> int:
        val &= 0xFF_FF_FF_FF
        return (
            ((val & 0xFF_00_00_00) >> 24) |
            ((val & 0x00_FF_00_00) >> 8)  |
            ((val & 0x00_00_FF_00) << 8)  |
            ((val & 0x00_00_00_FF) << 24)
        ) & 0xFF_FF_FF_FF

    @staticmethod
    def reverse_32_bits(n: int) -> int:
        """Reverse the bits of a 32-bit unsigned integer."""
        result = 0
        for i in range(32):
            result |= (n & 1) << (31 - i)
            n >>= 1
        return result

    @staticmethod
    async def obtain_files(path: str, exclude: list[str] | None = None, files: list[str] | None = None) -> list[str]:
        if exclude is None:
            exclude = []
        if files is None:
            # first run so check if a file is given
            if await aiofiles.os.path.isfile(path):
                basename = os.path.basename(path)
                if basename in exclude:
                    return []
                else:
                    return [path]
            files = []

        filelist = await aiofiles.os.listdir(path)

        for entry in filelist:
            entry_path = os.path.join(path, entry)

            if await aiofiles.os.path.isfile(entry_path) and entry not in exclude:
                files.append(entry_path)
            elif await aiofiles.os.path.isdir(entry_path) and entry_path != os.path.join(path, SCE_SYS_NAME):
                await CustomCrypto.obtain_files(entry_path, exclude, files)

        return files

