from __future__ import annotations
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from utils.helpers import DiscordContext

import os
import aiofiles.os

import discord
from discord.ui.item import Item

from data.crypto.exceptions import CryptoError
from utils.constants import (
    logger, OTHER_TIMEOUT, RANDOMSTRING_LENGTH,
    GTAV_TITLEID, BL3_TITLEID, RDR2_TITLEID, XENO2_TITLEID, WONDERLANDS_TITLEID, NDOG_TITLEID, NDOG_COL_TITLEID, NDOG_TLOU2_TITLEID,
    MGSV_TPP_TITLEID, MGSV_GZ_TITLEID, MGSV_DE_TITLEID, REV2_TITLEID, RE7_TITLEID, RERES_TITLEID, DL1_TITLEID, DL2_TITLEID, RGG_TITLEID,
    DI1_TITLEID, DI2_TITLEID, NMS_TITLEID, TERRARIA_TITLEID, SMT5_TITLEID, RCUBE_TITLEID, DSR_TITLEID, RE4R_TITLEID, RE3R_TITLEID, RE2R_TITLEID,
    DIGIMON_TITLEID, SDEW_TITLEID, NIOH2_TITLEID, MHWI_TITLEID, RE_VILLAGE_TITLEID, LA_NOIRE_TITLEID, LOH_TRAILS_CS4_TITLEID,
    LOH_TRAILS_DAYBREAK_TITLEID, LOH_TRAILS_ZERO_AZURE, MINECRAFT_TITLEID, FF7CC_TITLEID, TOSR_TITLEID, RE5_TITLEID, CCR_TITLEID,
    TOB_TITLEID, TR6R_TITLEID, STRIDER_TITLEID, DIABLO3_TITLEID, ALIEN_ISO_TITLEID, SHANTAE_SCURSE_TITLEID, MAFIA3_TITLEID, DEADRISING_TITLEID,
    KH3_TITLEID, PO_PERSIA_TITLEID, LUNAR_R_TITLEID, DSTRANDING_TITLEID, FC5_TITLEID, FF_PIXEL_TITLEID, SAO_FB_TITLEID, MHR_TITLEID,
    DOA5_LR_TITLEID, RE6_TITLEID, MEARTH_SOM_TITLEID, MEARTH_SOW_TITLEID, GS3_TITLEID, JFORCE_TITLEID, BALATRO_TITLEID, WWE_2K25_TITLEID,
    BO1_TITLEID, BO2_TITLEID
)
from utils.embeds import embdecTimeout, embdecFormat, embErrdec
from utils.extras import generate_random_string
from utils.namespaces import Crypto

async def extra_decrypt(
          d_ctx: DiscordContext | None,
          title_id: str,
          folderpath: str,
          savepairname: str,
          choice: bool | None = None
        ) -> None:

    from utils.helpers import TimeoutHelper

    if d_ctx is None:
        assert choice is not None
    if choice == False:
        return

    helper = TimeoutHelper(embdecTimeout)
    emb = embdecFormat.copy()
    emb.title = emb.title.format(savename=savepairname)

    class CryptChoiceButton(discord.ui.View):
        def __init__(self, game: str | None = None, start_offset: int | None = None) -> None:
            self.game = game
            self.offset = start_offset
            super().__init__(timeout=OTHER_TIMEOUT)

        async def on_timeout(self) -> None:
            self.disable_all_items()
            await helper.handle_timeout(d_ctx.msg)

        async def on_error(self, error: Exception, _: Item, __: discord.Interaction) -> None:
            self.disable_all_items()
            emb = embErrdec.copy()
            if isinstance(error, CryptoError):
                e = error
            else:
                e = "Unexpected error!"
            emb.description = emb.description.format(error=e)
            helper.embTimeout = emb
            await helper.handle_timeout(d_ctx.msg)
            logger.info(f"{error} - {d_ctx.ctx.user.name}")

        @discord.ui.button(label="Decrypted", style=discord.ButtonStyle.blurple, custom_id="decrypt")
        async def decryption_callback(self, _: discord.Button, interaction: discord.Interaction) -> None:
            if interaction.user != d_ctx.ctx.author:
                await interaction.response.send_message("This is not your instance!", ephemeral=True)
                return
            await interaction.response.edit_message(view=None)
            try:
                match self.game:
                    case "GTAV" | "RDR2":
                        await Crypto.Rstar.check_dec_ps(folderpath, self.offset)
                    case "XENO2":
                        await Crypto.Xeno2.check_dec_ps(folderpath)
                    case "BL3":
                        await Crypto.BL3.check_dec_ps(folderpath)
                    case "TTWL":
                        await Crypto.BL3.check_dec_ps(folderpath, True)
                    case "NDOG":
                        await Crypto.Ndog.check_dec_ps(folderpath, self.offset)
                    case "MGSV":
                        await Crypto.MGSV.check_dec_ps(folderpath, title_id, savepairname)
                    case "REV2":
                        await Crypto.Rev2.check_dec_ps(folderpath)
                    case "DL1" | "DI1":
                        await Crypto.DL.check_dec_ps(folderpath)
                    case "DL2":
                        await Crypto.DL2.check_dec_ps(folderpath)
                    case "DI2":
                        await Crypto.DI2.check_dec_ps(folderpath)
                    case "RGG":
                       await Crypto.RGG.check_dec_ps(folderpath)
                    case "NMS":
                        await Crypto.NMS.check_dec_ps(folderpath)
                    case "TERRARIA":
                        await Crypto.TERRARIA.check_dec_ps(folderpath)
                    case "SMT5":
                        await Crypto.SMT5.check_dec_ps(folderpath)
                    case "RCUBE":
                        await Crypto.RCube.check_dec_ps(folderpath)
                    case "DSR":
                        await Crypto.DSR.check_dec_ps(folderpath)
                    case "RE4R":
                        await Crypto.RE4R.check_dec_ps(folderpath)
                    case "RE2R":
                        await Crypto.RE4R.check_dec_ps(folderpath, True)
                    case "SDEW":
                        await Crypto.Sdew.check_dec_ps(folderpath)
                    case "NIOH2":
                        await Crypto.Nioh2.check_dec_ps(folderpath)
                    case "MHWI":
                        await Crypto.Mhwi.check_dec_ps(folderpath)
                    case "LANOIRE":
                        await Crypto.LaNoire.check_dec_ps(folderpath, savepairname)
                    case "LOHTRAILSCS4":
                        await Crypto.LoHTrails.check_dec_ps(folderpath)
                    case "FF7CC":
                        await Crypto.FF7CC.check_dec_ps(folderpath)
                    case "CCR":
                        await Crypto.CCR.check_dec_ps(folderpath)
                    case "TOB":
                        await Crypto.ToB.check_dec_ps(folderpath)
                    case "TR6R":
                        await Crypto.TR6R.check_dec_ps(folderpath)
                    case "DIABLO3":
                        await Crypto.Diablo3.check_dec_ps(folderpath)
                    case "SHANTAESCURSE":
                        await Crypto.ShantaeSCurse.check_dec_ps(folderpath)
                    case "POPERSIA":
                        await Crypto.PoPersia.check_dec_ps(folderpath)
                    case "FFPIXEL":
                        await Crypto.FFPixel.check_dec_ps(folderpath)
                    case "DOA5LR":
                        await Crypto.DoA5LR.check_dec_ps(folderpath)
                    case "GS3":
                        await Crypto.GS3.check_dec_ps(folderpath)
                    case "JFORCE":
                        await Crypto.JForce.check_dec_ps(folderpath)
                    case "BALATRO":
                        await Crypto.Balatro.check_dec_ps(folderpath)
                    case "WWE2K25":
                        await Crypto.WWE2K25.check_dec_ps(folderpath)
                    case "BO":
                        await Crypto.BO.check_dec_ps(folderpath)
            except (ValueError, IOError, IndexError):
                raise CryptoError("Invalid save!")

            helper.done = True

        @discord.ui.button(label="Encrypted", style=discord.ButtonStyle.blurple, custom_id="encrypt")
        async def encryption_callback(self, _: discord.Button, interaction: discord.Interaction) -> None:
            if interaction.user != d_ctx.ctx.author:
                await interaction.response.send_message("This is not your instance!", ephemeral=True)
                return
            await interaction.response.edit_message(view=None)
            helper.done = True

    if title_id in GTAV_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Rstar.check_dec_ps(folderpath, Crypto.Rstar.GTAV_PS_HEADER_OFFSET)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("GTAV", start_offset=Crypto.Rstar.GTAV_PS_HEADER_OFFSET))
        await helper.await_done()

    elif title_id in RDR2_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Rstar.check_dec_ps(folderpath, Crypto.Rstar.RDR2_PS_HEADER_OFFSET)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("RDR2", start_offset=Crypto.Rstar.RDR2_PS_HEADER_OFFSET))
        await helper.await_done()

    elif title_id in XENO2_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Xeno2.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("XENO2"))
        await helper.await_done()

    elif title_id in BL3_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.BL3.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("BL3"))
        await helper.await_done()

    elif title_id in WONDERLANDS_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.BL3.check_dec_ps(folderpath, True)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("TTWL"))
        await helper.await_done()

    elif title_id in NDOG_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Ndog.check_dec_ps(folderpath, Crypto.Ndog.START_OFFSET)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("NDOG", start_offset=Crypto.Ndog.START_OFFSET))
        await helper.await_done()

    elif title_id in NDOG_COL_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Ndog.check_dec_ps(folderpath, Crypto.Ndog.START_OFFSET_COL)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("NDOG", start_offset=Crypto.Ndog.START_OFFSET_COL))
        await helper.await_done()

    elif title_id in NDOG_TLOU2_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Ndog.check_dec_ps(folderpath, Crypto.Ndog.START_OFFSET_TLOU2)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("NDOG", start_offset=Crypto.Ndog.START_OFFSET_TLOU2))
        await helper.await_done()

    elif title_id in frozenset.union(MGSV_TPP_TITLEID, MGSV_GZ_TITLEID, MGSV_DE_TITLEID):
        if choice is not None:
            if choice:
                try:
                    await Crypto.MGSV.check_dec_ps(folderpath, title_id, savepairname)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("MGSV"))
        await helper.await_done()

    elif title_id in REV2_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Rev2.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("REV2"))
        await helper.await_done()

    elif title_id in DL1_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.DL.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("DL1"))
        await helper.await_done()

    elif title_id in DL2_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.DL2.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("DL2"))
        await helper.await_done()

    elif title_id in RGG_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.RGG.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("RGG"))
        await helper.await_done()

    elif title_id in DI1_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.DL.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("DI1"))
        await helper.await_done()

    elif title_id in DI2_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.DI2.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("DI2"))
        await helper.await_done()

    elif title_id in NMS_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.NMS.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("NMS"))
        await helper.await_done()

    elif title_id in TERRARIA_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.TERRARIA.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("TERRARIA"))
        await helper.await_done()

    elif title_id in SMT5_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.SMT5.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("SMT5"))
        await helper.await_done()

    elif title_id in RCUBE_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.RCube.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("RCUBE"))
        await helper.await_done()

    elif title_id in DSR_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.DSR.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("DSR"))
        await helper.await_done()

    elif title_id in RE4R_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.RE4R.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("RE4R"))
        await helper.await_done()

    elif title_id in RE2R_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.RE4R.check_dec_ps(folderpath, True)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("RE2R"))
        await helper.await_done()

    elif title_id in SDEW_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Sdew.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("SDEW"))
        await helper.await_done()

    elif title_id in NIOH2_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Nioh2.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("NIOH2"))
        await helper.await_done()

    elif title_id in MHWI_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Mhwi.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("MHWI"))
        await helper.await_done()

    elif title_id in LA_NOIRE_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.LaNoire.check_dec_ps(folderpath, savepairname)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("LANOIRE"))
        await helper.await_done()

    elif title_id in LOH_TRAILS_CS4_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.LoHTrails.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("LOHTRAILSCS4"))
        await helper.await_done()

    elif title_id in FF7CC_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.FF7CC.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("FF7CC"))
        await helper.await_done()

    elif title_id in CCR_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.CCR.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("CCR"))
        await helper.await_done()

    elif title_id in TOB_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.ToB.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("TOB"))
        await helper.await_done()

    elif title_id in TR6R_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.TR6R.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("TR6R"))
        await helper.await_done()

    elif title_id in DIABLO3_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Diablo3.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("DIABLO3"))
        await helper.await_done()

    elif title_id in SHANTAE_SCURSE_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.ShantaeSCurse.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("SHANTAESCURSE"))
        await helper.await_done()

    elif title_id in PO_PERSIA_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.PoPersia.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("POPERSIA"))
        await helper.await_done()

    elif title_id in FF_PIXEL_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.FFPixel.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("FFPIXEL"))
        await helper.await_done()

    elif title_id in DOA5_LR_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.DoA5LR.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("DOA5LR"))
        await helper.await_done()

    elif title_id in GS3_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.GS3.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("GS3"))
        await helper.await_done()

    elif title_id in JFORCE_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.JForce.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("JFORCE"))
        await helper.await_done()

    elif title_id in BALATRO_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.Balatro.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("BALATRO"))
        await helper.await_done()

    elif title_id in WWE_2K25_TITLEID:
        if choice is not None:
            if choice:
                try:
                    await Crypto.WWE2K25.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("WWE2K25"))
        await helper.await_done()

    elif title_id in frozenset.union(BO1_TITLEID, BO2_TITLEID):
        if choice is not None:
            if choice:
                try:
                    await Crypto.BO.check_dec_ps(folderpath)
                except (ValueError, IOError, IndexError):
                    raise CryptoError("Invalid save!")
            return

        await d_ctx.msg.edit(embed=emb, view=CryptChoiceButton("BO"))
        await helper.await_done()

async def extra_import(title_id: str, folderpath: str, savepairname: str) -> None:
    try:
        if title_id in GTAV_TITLEID:
            await Crypto.Rstar.check_enc_ps(folderpath, Crypto.Rstar.GTAV_PS_HEADER_OFFSET)

        elif title_id in RDR2_TITLEID:
            await Crypto.Rstar.check_enc_ps(folderpath, Crypto.Rstar.RDR2_PS_HEADER_OFFSET)

        elif title_id in XENO2_TITLEID:
            await Crypto.Xeno2.check_enc_ps(folderpath)

        elif title_id in BL3_TITLEID:
            await Crypto.BL3.check_enc_ps(folderpath)

        elif title_id in WONDERLANDS_TITLEID:
            await Crypto.BL3.check_enc_ps(folderpath, True)

        elif title_id in NDOG_TITLEID:
            await Crypto.Ndog.check_enc_ps(folderpath, Crypto.Ndog.START_OFFSET)

        elif title_id in NDOG_COL_TITLEID:
            await Crypto.Ndog.check_enc_ps(folderpath, Crypto.Ndog.START_OFFSET_COL)

        elif title_id in NDOG_TLOU2_TITLEID:
            await Crypto.Ndog.check_enc_ps(folderpath, Crypto.Ndog.START_OFFSET_TLOU2)

        elif title_id in frozenset.union(MGSV_TPP_TITLEID, MGSV_GZ_TITLEID, MGSV_DE_TITLEID):
            await Crypto.MGSV.check_enc_ps(folderpath, title_id, savepairname)

        elif title_id in REV2_TITLEID:
            await Crypto.Rev2.check_enc_ps(folderpath)

        elif title_id in frozenset.union(RE7_TITLEID, RERES_TITLEID, RE3R_TITLEID, RE_VILLAGE_TITLEID):
            await Crypto.RE7.check_enc_ps(folderpath)

        elif title_id in DL1_TITLEID:
            await Crypto.DL.check_enc_ps(folderpath, "DL1")

        elif title_id in DL2_TITLEID:
            await Crypto.DL2.check_enc_ps(folderpath)

        elif title_id in RGG_TITLEID:
            await Crypto.RGG.check_enc_ps(folderpath)

        elif title_id in DI1_TITLEID:
            await Crypto.DL.check_enc_ps(folderpath, "DI1")

        elif title_id in DI2_TITLEID:
            await Crypto.DI2.check_enc_ps(folderpath)

        elif title_id in NMS_TITLEID:
            await Crypto.NMS.check_enc_ps(folderpath)

        elif title_id in TERRARIA_TITLEID:
            await Crypto.TERRARIA.check_enc_ps(folderpath)

        elif title_id in SMT5_TITLEID:
            await Crypto.SMT5.check_enc_ps(folderpath)

        elif title_id in RCUBE_TITLEID:
            await Crypto.RCube.check_enc_ps(folderpath)

        elif title_id in DSR_TITLEID:
            await Crypto.DSR.check_enc_ps(folderpath)

        elif title_id in RE4R_TITLEID:
            await Crypto.RE4R.check_enc_ps(folderpath)

        elif title_id in RE2R_TITLEID:
            await Crypto.RE4R.check_enc_ps(folderpath, True)

        elif title_id in DIGIMON_TITLEID:
            await Crypto.Digimon.check_enc_ps(folderpath)

        elif title_id in SDEW_TITLEID:
            await Crypto.Sdew.check_enc_ps(folderpath)

        elif title_id in NIOH2_TITLEID:
            await Crypto.Nioh2.check_enc_ps(folderpath)

        elif title_id in MHWI_TITLEID:
            await Crypto.Mhwi.check_enc_ps(folderpath)

        elif title_id in LA_NOIRE_TITLEID:
            await Crypto.LaNoire.check_enc_ps(folderpath, savepairname)

        elif title_id in frozenset.union(LOH_TRAILS_CS4_TITLEID, LOH_TRAILS_DAYBREAK_TITLEID, LOH_TRAILS_ZERO_AZURE):
            await Crypto.LoHTrails.check_enc_ps(folderpath, title_id)

        elif title_id in FF7CC_TITLEID:
            await Crypto.FF7CC.check_enc_ps(folderpath)

        elif title_id in TOSR_TITLEID:
            await Crypto.ToSR.check_enc_ps(folderpath)

        elif title_id in RE5_TITLEID:
            await Crypto.RE5.check_enc_ps(folderpath)

        elif title_id in CCR_TITLEID:
            await Crypto.CCR.check_enc_ps(folderpath)

        elif title_id in TOB_TITLEID:
            await Crypto.ToB.check_enc_ps(folderpath)

        elif title_id in TR6R_TITLEID:
            await Crypto.TR6R.check_enc_ps(folderpath)

        elif title_id in STRIDER_TITLEID:
            await Crypto.Strider.check_enc_ps(folderpath)

        elif title_id in DIABLO3_TITLEID:
            await Crypto.Diablo3.check_enc_ps(folderpath)

        elif title_id in ALIEN_ISO_TITLEID:
            await Crypto.AlienIso.check_enc_ps(folderpath)

        elif title_id in SHANTAE_SCURSE_TITLEID:
            await Crypto.ShantaeSCurse.check_enc_ps(folderpath)

        elif title_id in MAFIA3_TITLEID:
            await Crypto.Mafia3.check_enc_ps(folderpath)

        elif title_id in DEADRISING_TITLEID:
            await Crypto.DeadRising.check_enc_ps(folderpath)

        elif title_id in KH3_TITLEID:
            await Crypto.KH3.check_enc_ps(folderpath)

        elif title_id in PO_PERSIA_TITLEID:
            await Crypto.PoPersia.check_enc_ps(folderpath)

        elif title_id in LUNAR_R_TITLEID:
            await Crypto.LunarR.check_enc_ps(folderpath, savepairname)

        elif title_id in DSTRANDING_TITLEID:
            await Crypto.DStranding.check_enc_ps(folderpath)

        elif title_id in FC5_TITLEID:
            await Crypto.FC5.check_enc_ps(folderpath)

        elif title_id in FF_PIXEL_TITLEID:
            await Crypto.FFPixel.check_enc_ps(folderpath)

        elif title_id in SAO_FB_TITLEID:
            await Crypto.SAOFB.check_enc_ps(folderpath)

        elif title_id in MHR_TITLEID:
            await Crypto.MHR.check_enc_ps(folderpath)

        elif title_id in DOA5_LR_TITLEID:
            await Crypto.DoA5LR.check_enc_ps(folderpath)

        elif title_id in RE6_TITLEID:
            await Crypto.RE6.check_enc_ps(folderpath)

        elif title_id in frozenset.union(MEARTH_SOM_TITLEID, MEARTH_SOW_TITLEID):
            await Crypto.MEarth.check_enc_ps(folderpath)

        elif title_id in GS3_TITLEID:
            await Crypto.GS3.check_enc_ps(folderpath)

        elif title_id in JFORCE_TITLEID:
            await Crypto.JForce.check_enc_ps(folderpath)

        elif title_id in BALATRO_TITLEID:
            await Crypto.Balatro.check_enc_ps(folderpath)

        elif title_id in WWE_2K25_TITLEID:
            await Crypto.WWE2K25.check_enc_ps(folderpath)

        elif title_id in frozenset.union(BO1_TITLEID, BO2_TITLEID):
            await Crypto.BO.check_enc_ps(folderpath)
    except (ValueError, IOError, IndexError):
        raise CryptoError("Invalid save!")

async def extra_reregion_pre(
          folderpath: str,
          title_id: str,
          savepairname: str,
        ) -> str:
    """On decrypted savepairs. Returns new savepairname or empty string."""

    new_name = ""
    try:
        if title_id in XENO2_TITLEID:
            new_name = Crypto.Xeno2.reregion_get_new_name(title_id)

        elif title_id in frozenset.union(MGSV_TPP_TITLEID, MGSV_GZ_TITLEID, MGSV_DE_TITLEID):
            await Crypto.MGSV.reregion_change_crypt(folderpath, title_id, savepairname)
            new_name = Crypto.MGSV.reregion_get_new_name(title_id, savepairname)

        elif title_id in MINECRAFT_TITLEID:
            new_name = Crypto.Minecraft.reregion_get_new_name(title_id, savepairname)

        elif title_id in REV2_TITLEID:
            new_name = Crypto.Rev2.reregion_get_new_name(title_id)
    except (ValueError, IOError, IndexError):
        raise CryptoError("Invalid save!")
    return new_name

def extra_reregion_pre_needs_folder(
          title_id: str,
        ) -> bool:

    if title_id in frozenset.union(MGSV_TPP_TITLEID, MGSV_GZ_TITLEID, MGSV_DE_TITLEID):
        return True

    return False

async def extra_reregion_post(
          savepath: str,
          title_id: str,
        ) -> str | None:
    """
    On encrypted savepairs.
    Renames the save after re-regioning for the games that need it, random string is appended at the end for no overwriting.
    """

    savepairname = os.path.basename(savepath)

    if title_id in XENO2_TITLEID:
        new_name = Crypto.Xeno2.reregion_get_new_name(title_id)

    elif title_id in frozenset.union(MGSV_TPP_TITLEID, MGSV_GZ_TITLEID, MGSV_DE_TITLEID):
        new_name = Crypto.MGSV.reregion_get_new_name(title_id, savepairname)

    elif title_id in MINECRAFT_TITLEID:
        new_name = Crypto.Minecraft.reregion_get_new_name(title_id, savepairname)

    elif title_id in REV2_TITLEID:
        new_name = Crypto.Rev2.reregion_get_new_name(title_id)

    else:
        return
    if not new_name:
        return
    if savepairname == new_name:
        return

    savefolder = os.path.dirname(savepath)
    new_file = os.path.join(savefolder, new_name)
    if await aiofiles.os.path.exists(new_file):
        rand_str = generate_random_string(RANDOMSTRING_LENGTH)
        new_file = os.path.join(savefolder, new_name + f"_{rand_str}")
    await aiofiles.os.rename(savepath, new_file)
    await aiofiles.os.rename(savepath + ".bin", new_file + ".bin")
    return new_file

