import os
import discord
import asyncio
import json
import aiofiles
import aiofiles.os
import re
import datetime
import aiohttp
import errno

from sys import argv
from discord.ext import tasks
from aiogoogle import Aiogoogle, auth, HTTPError, models
from dateutil import parser
from enum import Enum, auto
from typing import Any

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google.auth.exceptions import RefreshError
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

from google_drive.exceptions import GDapiError
from utils.orbis import (
    parse_pfs_header, parse_sealedkey,
    get_savedirname_filename_len, get_savedirname_path_len, get_path_len
)
from utils.extras import generate_random_string
from utils.constants import (
    SYS_FILE_MAX, MAX_PATH_LEN, MAX_FILENAME_LEN, SEALED_KEY_ENC_SIZE, SAVESIZE_MAX, GENERAL_CHUNKSIZE,
    RANDOMSTRING_LENGTH, SCE_SYS_CONTENTS, MAX_FILES, SCE_SYS_NAME,
    logger
)
from utils.embeds import (
    gd_upl_progress_emb, embgddone
)
from utils.exceptions import FileError
from utils.conversions import gb_to_bytes, bytes_to_mb, round_half_up, minutes_to_seconds

FOLDER_ID_RE = re.compile(r"/folders/([\w-]+)")
GD_LINK_RE = re.compile(r"https://drive\.google\.com/.*")
BOT_FOLDER_NAME = "HTOS_Bot"  # Dedicated folder for bot operations

class GDapi:
    class AccountType(Enum):
        SERVICE_ACCOUNT = auto()
        PERSONAL_ACCOUNT = auto()

    """Async functions to interact with the Google Drive API."""
    SAVEGAME_MAX = SAVESIZE_MAX
    TOTAL_SIZE_LIMIT = gb_to_bytes(2)
    MAX_USER_NESTING = 100 # how deep a user can go when uploading files to create a save with
    MAX_FILES_IN_DIR = MAX_FILES
    UPLOAD_CHUNKSIZE = GENERAL_CHUNKSIZE
    UPLOAD_CHUNK_TIMEOUT = aiohttp.ClientTimeout(
        total=minutes_to_seconds(10),
        sock_connect=30
    )
    RANGE_PATTERN = re.compile(r"bytes=(\d+)-(\d+)")
    TAG_KEY = "purpose"
    TAG_VALUE = "HTOS"

    def __init__(self) -> None:
        assert self.UPLOAD_CHUNKSIZE % (256 * 1024) == 0

        if self.MAX_FILES_IN_DIR < 1000:
           self.pagesizes = [self.MAX_FILES_IN_DIR]
        else:
            q, r = divmod(self.MAX_FILES_IN_DIR, 1000)
            self.pagesizes = [1000 for _ in range(q)]
            self.pagesizes.append(r)

        self.creds:        dict[str, Any]    | None = None
        self.account_type: GDapi.AccountType | None = None

        if not self.authorize():
            return

        # Initialize the bot's dedicated folder on startup
        try:
            self.bot_folder_id = asyncio.run(self.get_bot_folder_id()) # Cached bot folder ID
        except HTTPError as e:
            logger.error(f"Failed to initialize bot folder: {e}")
            raise GDapiError(self.get_err_str_HTTPERROR(e))
        logger.info("Google Drive bot folder initialized successfully")

    def is_available(self) -> bool:
        return self.creds is not None and self.account_type is not None

    def is_available_check(self) -> None:
        if not self.is_available():
            raise GDapiError("Google Drive is unavailable on the bot's end!")

    def authorize(self) -> bool:
        CREDENTIALS_PATH = os.getenv("GOOGLE_DRIVE_JSON_PATH")
        if not CREDENTIALS_PATH:
            print("Google Drive credentials are unavailable.")
            return False

        SCOPE = ["https://www.googleapis.com/auth/drive"]

        if not os.path.isfile(CREDENTIALS_PATH):
            raise GDapiError("Credentials path does not exist or is not a file!")

        # check if it is a service account
        serviceacc_creds = {
            "scopes": SCOPE,
            **json.load(open(CREDENTIALS_PATH))
        }
        acc_type = serviceacc_creds.get("type", "")
        if acc_type == "service_account":
            self.creds = {"service_account_creds": serviceacc_creds}
            self.account_type = self.AccountType.SERVICE_ACCOUNT
            return True

        CACHED_CREDENTIALS_PATH = os.path.join(os.path.dirname(CREDENTIALS_PATH), "token.json")

        # try to get cached oauth credentials
        if os.path.isfile(CACHED_CREDENTIALS_PATH):
            try:
                creds = Credentials.from_authorized_user_file(CACHED_CREDENTIALS_PATH, SCOPE)
            except ValueError:
                creds = None
        else:
            creds = None

        if not creds or not creds.valid:
            # refresh or obtain oauth credentials
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                except RefreshError:
                    creds = None
            else:
                creds = None
            if not creds:
                flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_PATH, SCOPE)
                creds = flow.run_local_server(port=0)
            with open(CACHED_CREDENTIALS_PATH, "w") as token:
                token.write(creds.to_json())
        build("drive", "v3", credentials=creds)

        client_creds = auth.creds.ClientCreds(
            creds.client_id,
            creds.client_secret,
            creds.scopes
        )
        user_creds = auth.creds.UserCreds(
            refresh_token=creds.refresh_token,
            scopes=creds.scopes,
            id_token=creds.id_token,
            token_uri=creds.token_uri
        )
        self.creds = {"client_creds": client_creds, "user_creds": user_creds}
        self.account_type = self.AccountType.PERSONAL_ACCOUNT
        return True

    async def get_bot_folder_id(self) -> str:
        """Get or create the bot's dedicated folder."""
        self.is_available_check()

        async with Aiogoogle(**self.creds) as aiogoogle:
            drive_v3 = await aiogoogle.discover("drive", "v3")

            # Search for existing bot folder
            req = drive_v3.files.list(
                q=f"name='{BOT_FOLDER_NAME}' and mimeType='application/vnd.google-apps.folder' and trashed=false",
                fields="files(id, name)",
                pageSize=1
            )
            res = await self.send_req(aiogoogle, req)
            files = res.get("files", [])

            if files:
                # Folder exists, use it
                bot_folder_id = files[0]["id"]
                logger.info(f"Found existing bot folder: {bot_folder_id}")
            else:
                # Create new folder
                req = drive_v3.files.create(
                    json={
                        "name": BOT_FOLDER_NAME,
                        "mimeType": "application/vnd.google-apps.folder"
                    },
                    fields="id"
                )
                res = await self.send_req(aiogoogle, req)
                bot_folder_id = res["id"]
                logger.info(f"Created bot folder: {bot_folder_id}")

        return bot_folder_id

    async def send_req(self, aiogoogle: Aiogoogle, req: models.Request, full_res: bool = False) -> models.Response:
        assert self.is_available()

        match self.account_type:
            case self.AccountType.SERVICE_ACCOUNT:
                return await aiogoogle.as_service_account(req, full_res=full_res)
            case self.AccountType.PERSONAL_ACCOUNT:
                return await aiogoogle.as_user(req, full_res=full_res)

    @staticmethod
    def get_folderid(folder_link: str) -> str:
        if not folder_link:
            raise GDapiError("Invalid folder link!")
        match = FOLDER_ID_RE.search(folder_link)
        if not match:
            raise GDapiError("Invalid folder link!")
        folder_id = match.group(1)
        return folder_id

    @staticmethod
    def is_google_drive_link(text: str) -> bool:
        return bool(GD_LINK_RE.match(text))

    @staticmethod
    def get_err_str_HTTPERROR(e: HTTPError) -> str:
        if e.res is None:
            return "HTTPError!"

        err = e.res.content.get("error")
        if isinstance(err, dict):
            err_code = err.get("code")
        else:
            logger.error(f"Unexpected GD error (1): {err}")
            return "UNEXPECTED GD ERROR."

        err_msg = []

        err_list = err.get("errors")
        if isinstance(err_list, list):
            for error in err_list:
                err_msg.append(error.get("reason"))
        else:
            logger.error(f"Unexpected GD error (2): {err_list}")

        if len(err_msg) == 1:
            err_msg = err_msg[0]
        else:
            err_msg = ", ".join(err_msg)

        return f"Google Drive: HTTPERROR ({err_code}): {err_msg}."

    @staticmethod
    def parse_HTTPERROR_simple(e: HTTPError) -> tuple[int, str]:
        if e.res is None:
            raise GDapiError("Failed to upload to Google Drive, please try again.")

        err = e.res.content.get("error")
        if not isinstance(err, dict):
            logger.error(f"Unexpected GD error (1): {err}")
            raise GDapiError("Unexpected GD error!")
        err_code = err.get("code")

        err_list = err.get("errors")
        if not isinstance(err_list, list):
            logger.error(f"Unexpected GD error (2): {err_list}")
            raise GDapiError("Unexpected GD error!")
        err_reason = err_list[0].get("reason")

        return err_code, err_reason

    @staticmethod
    def file_check(
        file_data: list[dict[str, str | int]],
        sys_files: frozenset[str] | None,
        ps_save_pair_upload: bool,
        ignore_filename_check: bool,
        savesize: int | None = None
    ) -> list[dict[str, str]]:

        valid_files_data = []
        total_size = 0

        if ps_save_pair_upload:
            # assume the normal orbis filesystem is case sensitive
            # this should be a case sensitive check
            # that works on both case sensitive and case insensitive filesystems
            # that is because of batch logic (new batch is made if dupe exists on filesystem)
            paths = set()
            for file_info in file_data:
                path = file_info["filepath"]
                if path in paths:
                    raise FileError("Duplicate file detected (case-sensitive check)!")
                paths.add(path)
            valid_files_data = GDapi.save_pair_check(file_data)
            return valid_files_data

        # assume files inside save containers are case insensitive by default (which is the scope of this branch)
        # this should be a case insensitive check
        # that works on both case sensitive and case insensitive filesystems
        paths = set()
        for file_info in file_data:
            path = file_info["filepath"]
            if path.lower() in paths:
                raise FileError("Duplicate file detected (case-insensitive check)!")
            paths.add(path.lower())

        for file_info in file_data:
            filepath = file_info["filepath"]
            file_id = file_info["fileid"]
            file_size = file_info["filesize"]

            if len(filepath) > MAX_FILENAME_LEN and not ignore_filename_check:
                raise FileError(f"The length of a file name exceeds {MAX_FILENAME_LEN}!")

            elif file_size > GDapi.SAVEGAME_MAX:
                raise FileError(f"The size of a file exceeds {bytes_to_mb(GDapi.SAVEGAME_MAX)} MB!")

            elif (sys_files is not None) and (file_size > SYS_FILE_MAX or filepath not in sys_files): # sce_sys files are not that big
                raise FileError("Invalid sce_sys file uploaded!")

            elif savesize is not None and total_size + file_size > savesize:
                raise FileError(f"The files you are uploading for this save exceeds the savesize {bytes_to_mb(savesize)} MB!")

            else:
                total_size += file_size
                file_data = {"filepath": filepath, "fileid": file_id, "filesize": file_size}
                valid_files_data.append(file_data)
        return valid_files_data

    @staticmethod
    def save_pair_check(file_data: list[dict[str, str | int]]) -> list[dict[str, str | int]]:
        valid_saves_check1 = []
        for file_info in file_data:
            file_path = file_info["filepath"]
            file_size = file_info["filesize"]
            file_id = file_info["fileid"]

            file_name = os.path.basename(file_path)
            file_name_len = get_savedirname_filename_len(file_name)
            path_len = get_savedirname_path_len(file_name)

            if file_name_len > MAX_FILENAME_LEN:
                raise FileError(f"The length of a file name exceeds {MAX_FILENAME_LEN}!")

            elif path_len > MAX_PATH_LEN:
                raise FileError(f"The length of a path is exceeding {MAX_PATH_LEN}!")

            elif file_path.endswith(".bin"):
                if file_size != SEALED_KEY_ENC_SIZE:
                    raise FileError(f"Invalid .bin file uploaded!")

                else:
                    file_data = {"filepath": file_path, "fileid": file_id, "filesize": file_size}
                    valid_saves_check1.append(file_data)
            else:
                if file_size > GDapi.SAVEGAME_MAX:
                    raise FileError(f"The size of a file exceeds {bytes_to_mb(GDapi.SAVEGAME_MAX)} MB!")
                else:
                    file_data = {"filepath": file_path, "fileid": file_id, "filesize": file_size}
                    valid_saves_check1.append(file_data)

        valid_saves_final = []
        for file_info in valid_saves_check1:
            file_path = file_info["filepath"]
            file_id = file_info["fileid"]
            file_size = file_info["filesize"]

            if file_path.endswith(".bin"): # look for corresponding file
                for file_info_nested in valid_saves_check1:
                    file_path_nested = file_info_nested["filepath"]
                    file_id_nested = file_info_nested["fileid"]
                    file_size_nested = file_info_nested["filesize"]
                    if file_path_nested == file_path:
                        continue

                    elif file_path_nested == os.path.splitext(file_path)[0]:
                        file_data = {"filepath": file_path, "fileid": file_id, "filesize": file_size}
                        valid_saves_final.append(file_data)
                        file_data_nested = {"filepath": file_path_nested, "fileid": file_id_nested, "filesize": file_size_nested}
                        valid_saves_final.append(file_data_nested)
                        break
        return valid_saves_final

    async def list_dir(
              self,
              folder_id: str,
              sys_files: frozenset[str] | None,
              ps_save_pair_upload: bool,
              ignore_filename_check: bool,
              mounted_len_checks: bool = False,
              cur_nesting: int = 0,
              total_filesize: int = 0,
              rel_path: str | None = None,
              files: list[dict[str, str]] | None = None
            ) -> tuple[list[dict[str, str | int]], int]:
        self.is_available_check()

        if files is None:
            files = []

        if cur_nesting > self.MAX_USER_NESTING:
            raise FileError(f"Max level nesting of {self.MAX_USER_NESTING} reached!")

        entries = []
        next_page_token = ""

        async with Aiogoogle(**self.creds) as aiogoogle:
            drive_v3 = await aiogoogle.discover("drive", "v3")

            for pagesize in self.pagesizes:
                req = drive_v3.files.list(
                    q=f"'{folder_id}' in parents and trashed=false",
                    fields="files(name, id, size, mimeType), nextPageToken",
                    pageSize=pagesize,
                    pageToken=next_page_token
                )

                res = await self.send_req(aiogoogle, req)

                entries.extend(res.get("files", []))
                next_page_token = res.get("nextPageToken")
                if not next_page_token:
                    break

        if next_page_token:
            raise FileError("Maximum entries has been exceeded!")

        file_data_storage = []

        for file_info in entries:
            mimetype = file_info["mimeType"]
            name = file_info["name"]
            id_ = file_info["id"]
            file_size = int(file_info.get("size", 0))

            if mimetype == "application/vnd.google-apps.folder":
                folder_name = name
                folder_id = id_
                if folder_name in (".", "..") or folder_name == SCE_SYS_NAME:
                    continue

                if rel_path is not None:
                    rel_path = os.path.join(rel_path, folder_name)
                else:
                    rel_path = folder_name
                rel_path = os.path.normpath(rel_path)
                if mounted_len_checks:
                    path_len = get_path_len(rel_path)
                    if path_len > MAX_PATH_LEN:
                        raise FileError(f"The length of a path is exceeding {MAX_PATH_LEN}!")

                _, sub_size = await self.list_dir(
                    folder_id, sys_files, ps_save_pair_upload, ignore_filename_check,
                    mounted_len_checks, cur_nesting + 1, total_filesize, rel_path, files
                )
                total_filesize += sub_size
                # go up one level
                rel_path = os.path.dirname(rel_path)
            else:
                file_name = name
                file_id = id_
                if file_size == 0 or file_name in (".", "..") or (file_name in SCE_SYS_CONTENTS and sys_files is None):
                    continue

                if rel_path is not None:
                    file_path = os.path.join(rel_path, file_name)
                else:
                    file_path = file_name
                file_path = os.path.normpath(file_path)
                if mounted_len_checks:
                    path_len = get_path_len(file_path)
                    if len(file_name) > MAX_FILENAME_LEN:
                        raise FileError(f"The length of a file name is exceeding {MAX_FILENAME_LEN}!")
                    elif path_len > MAX_PATH_LEN:
                        raise FileError(f"The length of a path is exceeding {MAX_PATH_LEN}!")

                file_data = {"filepath": file_path, "fileid": file_id, "filesize": file_size}
                file_data_storage.append(file_data)

        valid_file_data = GDapi.file_check(file_data_storage, sys_files, ps_save_pair_upload, ignore_filename_check)
        for data in valid_file_data:
            file_path = data["filepath"]
            file_id = data["fileid"]
            file_size = data["filesize"]

            file_data = {"filepath": file_path, "fileid": file_id, "filesize": file_size}
            files.append(file_data)
            total_filesize += file_size

        return files, total_filesize

    async def list_drive(self) -> list[dict[str, str]]:
        """List all files within the bot's dedicated folder only."""
        self.is_available_check()

        async with Aiogoogle(**self.creds) as aiogoogle:
            drive_v3 = await aiogoogle.discover("drive", "v3")

            files = []
            next_page_token = ""

            while next_page_token is not None:
                req = drive_v3.files.list(
                    q=f"'me' in owners and appProperties has {{ key='{self.TAG_KEY}' and value='{self.TAG_VALUE}' }}",
                    pageSize=1000,
                    fields="nextPageToken, files(id, createdTime)",
                    pageToken=next_page_token
                )

                res = await self.send_req(aiogoogle, req)
                files.extend(res.get("files", []))
                next_page_token = res.get("nextPageToken")

            return files

    async def clear_drive(self, files: list[dict[str, str]] | None = None) -> None:
        """Clear files only related to the bot."""

        if files is None:
            try:
                files = await self.list_drive()
            except HTTPError as e:
                logger.error(f"Failed to list files in drive related to the bot: {e}")
                return

        logger.info(f"Clearing {len(files)} files in drive related to the bot")
        for file in files:
            file_id = file["id"]
            try:
                await self.delete_file(file_id)
            except HTTPError:
                pass

    async def check_drive_storage(self) -> bool:
        self.is_available_check()

        async with Aiogoogle(**self.creds) as aiogoogle:
            try:
                drive_v3 = await aiogoogle.discover("drive", "v3")

                req = drive_v3.about.get(
                    fields="storageQuota"
                )
                res = await self.send_req(aiogoogle, req)
            except HTTPError as e:
                logger.error(f"GD-Error while checking drive storage: {e}")
                raise GDapiError("Failed to check drive storage!")
        storage_quota = res["storageQuota"]
        if storage_quota:
            limit = int(storage_quota["limit"])
            usage = int(storage_quota["usage"])
            return (limit - usage) >= self.TOTAL_SIZE_LIMIT
        return False

    async def delete_file(self, fileid: str) -> None:
        self.is_available_check()

        async with Aiogoogle(**self.creds) as aiogoogle:
            drive_v3 = await aiogoogle.discover("drive", "v3")

            req = drive_v3.files.get(fileId=fileid, fields="capabilities")
            res = await self.send_req(aiogoogle, req)

            can_delete = res.get("capabilities", {}).get("canDelete", False)

            if can_delete:
                req = drive_v3.files.delete(fileId=fileid)
                await self.send_req(aiogoogle, req)

    async def check_writeperm(self, folderid: str) -> bool:
        self.is_available_check()

        async with Aiogoogle(**self.creds) as aiogoogle:
            drive_v3 = await aiogoogle.discover("drive", "v3")

            req = drive_v3.permissions.list(fileId=folderid, fields="permissions")
            try:
                res = await self.send_req(aiogoogle, req)
            except HTTPError as e:
                code, reason = self.parse_HTTPERROR_simple(e)
                if code == 403 and reason == "insufficientFilePermissions":
                    return False
                raise GDapiError(self.get_err_str_HTTPERROR(e))

        if res["permissions"][0]["role"] != "writer":
            return False
        return True

    async def parse_sharedfolder_link(self, link: str) -> str:
        if not link:
            return ""
        folderid = self.get_folderid(link)
        writeperm = await self.check_writeperm(folderid)
        if not writeperm:
            raise GDapiError("Shared folder has insufficent permissions! Enable write permission.")
        return folderid

    async def uploadzip(self,
              ctx: discord.ApplicationContext | discord.Message,
              file_path: str,
              file_name: str,
              shared_folderid: str = ""
            ) -> str:
        self.is_available_check()

        metadata = {"name": file_name}
        if shared_folderid:
            metadata["parents"] = [shared_folderid]
        else:
            # Default to bot's dedicated folder
            metadata["parents"] = [self.bot_folder_id]
        # Tag metadata with appProperties
        metadata["appProperties"] = {
            self.TAG_KEY: self.TAG_VALUE
        }

        filesize = await aiofiles.os.path.getsize(file_path)

        # Initial request for resumable upload
        async with Aiogoogle(**self.creds) as aiogoogle:
            try:
                drive_v3 = await aiogoogle.discover("drive", "v3")
                req_init = models.Request(
                    method="POST",
                    url="https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id&supportsAllDrives=True",
                    json=metadata,
                    headers={
                        "X-Upload-Content-Length": str(filesize),
                        "Content-Type": "application/json; charset=UTF-8",
                    },
                    upload_file_content_type="application/zip"
                )
                res_init = await self.send_req(aiogoogle, req_init, full_res=True)
                location = res_init.headers["Location"]
            except HTTPError as e:
                raise GDapiError(self.get_err_str_HTTPERROR(e))

        # Upload in chunks
        file_id = None
        start_pos = 0
        file = await aiofiles.open(file_path, "rb")
        emb = gd_upl_progress_emb.copy()
        async with aiohttp.ClientSession(timeout=self.UPLOAD_CHUNK_TIMEOUT) as session:
            while start_pos < filesize:
                emb.description = f"{round_half_up((start_pos / filesize) * 100)}%"
                await ctx.edit(embed=emb)

                await file.seek(start_pos)
                chunk = await file.read(self.UPLOAD_CHUNKSIZE)
                chunk_size = len(chunk)
                end_pos = start_pos + chunk_size - 1

                try:
                    async with session.put(
                        url=location,
                        data=chunk,
                        headers={
                            "Content-Length": str(chunk_size),
                            "Content-Range": f"bytes {start_pos}-{end_pos}/{filesize}"
                        }
                    ) as upload_res:
                        if upload_res.status >= 400:
                            try:
                                body = await upload_res.json()
                            except aiohttp.ContentTypeError:
                                body = await upload_res.text()
                            logger.error(
                                f"Google Drive upload failed:\n"
                                f"Status: {upload_res.status} {upload_res.reason}\n"
                                f"Response body: {body}"
                            )
                            raise GDapiError(f"Upload failed with status code {upload_res.status}!")

                        if upload_res.status == 308:
                            range_header = upload_res.headers.get("Range", "")
                            range_pos = self.RANGE_PATTERN.fullmatch(range_header)
                            if not range_pos:
                                # If Range is not present then no bytes were receieved, but we will not be retrying
                                raise GDapiError("Unexpected error!")
                            start_pos = int(range_pos.group(2)) + 1
                        elif upload_res.status in (200, 201):
                            try:
                                body = await upload_res.json()
                            except aiohttp.ContentTypeError:
                                raise GDapiError("Unexpected error!")
                            file_id = body["id"]
                            emb.description = "100%"
                            await ctx.edit(embed=emb)
                            logger.info(f"Uploaded {file_path} to google drive")
                            break
                        else:
                            logger.error(
                                f"Google Drive upload: Unexpected status code:\n"
                                f"Status: {upload_res.status} {upload_res.reason}\n"
                                f"Response body: {body}"
                            )
                            raise GDapiError(f"Upload failed with status code {upload_res.status}!")
                except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                    await file.close()
                    logger.error(f"GD chunk upload request error: {e}")
                    raise GDapiError("Error while uploading chunk!")
                except Exception:
                    await file.close()
                    raise
        await file.close()

        # Set permissions
        async with Aiogoogle(**self.creds) as aiogoogle:
            try:
                drive_v3 = await aiogoogle.discover("drive", "v3")

                perm_req = drive_v3.permissions.create(
                    fileId=file_id,
                    json={"role": "reader", "type": "anyone", "allowFileDiscovery": False}
                )
                await self.send_req(aiogoogle, perm_req)
            except HTTPError as e:
                raise GDapiError(self.get_err_str_HTTPERROR(e))

        file_url = f"https://drive.google.com/file/d/{file_id}"
        return file_url

    async def downloadsaves_recursive(
              self,
              ctx: discord.ApplicationContext | discord.Message,
              folder_id: str,
              download_dir: str,
              max_files: int,
              sys_files: frozenset[str] | None,
              ps_save_pair_upload: bool,
              ignore_filename_check: bool,
              allow_duplicates: bool = False
            ) -> list[list[str]]:
        """Setting `ps_save_pair_upload` to `True` will also set `allow_duplicates` to `True`."""
        self.is_available_check()
        from utils.helpers import embed_edit

        if ps_save_pair_upload:
            allow_duplicates = True

        files, total_filesize = await self.list_dir(folder_id, sys_files, ps_save_pair_upload, ignore_filename_check)
        filecount = len(files)
        uploaded_file_paths = []
        if filecount == 0:
            raise FileError("Invalid files uploaded, or no files found!")
        elif filecount > max_files:
            raise FileError(f"Amount of files cannot exceed {max_files}!")
        elif total_filesize > self.TOTAL_SIZE_LIMIT:
            raise FileError(f"Total size cannot exceed {bytes_to_mb(self.TOTAL_SIZE_LIMIT)} MB!")

        if allow_duplicates:
            # enforce no files in root, only dirs
            cur_download_dir = os.path.join(download_dir, os.path.basename(download_dir))
            await aiofiles.os.mkdir(cur_download_dir)
        else:
            cur_download_dir = download_dir

        download_cycle = []
        i = 1
        async with Aiogoogle(**self.creds) as aiogoogle:
            drive_v3 = await aiogoogle.discover("drive", "v3")

            for file in files:
                file_name = os.path.basename(file["filepath"])
                if not file_name or file_name in (".", ".."):
                    raise FileError("Invalid file uploaded!")
                file_id = file["fileid"]

                download_path = os.path.join(cur_download_dir, file_name)
                if await aiofiles.os.path.exists(download_path):
                    if allow_duplicates:
                        cur_download_dir = os.path.join(download_dir, generate_random_string(RANDOMSTRING_LENGTH))
                        await aiofiles.os.mkdir(cur_download_dir)
                        download_path = os.path.join(cur_download_dir, file_name)
                        uploaded_file_paths.append(download_cycle)
                        download_cycle = []
                    else:
                        continue
                try:
                    async with aiofiles.open(download_path, "wb") as file:
                        req = drive_v3.files.get(
                            fileId=file_id, pipe_to=file, alt="media"
                        )
                        await self.send_req(aiogoogle, req)
                except OSError as e:
                    if e.errno == errno.EINVAL:
                        raise FileError(f"A filename is unsupported!")
                    raise
                logger.info(f"Saved {file_name} to {download_path}")

                # run a quick check
                if ps_save_pair_upload and not file_name.endswith(".bin"):
                    await parse_pfs_header(download_path)
                elif ps_save_pair_upload and file_name.endswith(".bin"):
                    await parse_sealedkey(download_path)

                await embed_edit(
                    ctx, embgddone,
                    description_kwargs=dict(
                        filename=file_name, i=i, filecount=filecount
                    )
                )

                download_cycle.append(download_path)
                i += 1
        uploaded_file_paths.append(download_cycle)
        return uploaded_file_paths

    async def downloadfiles_recursive(
              self,
              ctx: discord.ApplicationContext | discord.Message,
              dst_local_dir: str,
              folder_id: str,
              max_files: int,
              savesize: int | None = None
            ) -> list[list[str]]:
        """For encrypt & createsave command."""
        self.is_available_check()
        from utils.helpers import embed_edit

        files, total_filesize = await self.list_dir(folder_id, None, False, True, mounted_len_checks=True)
        filecount = len(files)
        if filecount == 0:
            raise FileError("Invalid files uploaded, or no files found!")
        elif filecount > max_files:
            raise FileError(f"Amount of files cannot exceed {max_files}!")
        elif total_filesize > self.TOTAL_SIZE_LIMIT:
            raise FileError(f"Total size cannot exceed: {self.TOTAL_SIZE_LIMIT}!")
        elif savesize is not None and total_filesize > savesize:
            raise FileError(f"The files you are uploading for this save exceeds the savesize {bytes_to_mb(savesize)} MB!")

        ld = os.path.realpath(dst_local_dir)
        uploaded_file_paths = []
        async with Aiogoogle(**self.creds) as aiogoogle:
            drive_v3 = await aiogoogle.discover("drive", "v3")

            i = 1
            for file in files:
                file_path = file["filepath"]
                file_id = file["fileid"]

                download_path = os.path.join(dst_local_dir, file_path)
                dp = os.path.realpath(download_path)
                if os.path.commonpath([ld, dp]) != ld:
                    raise FileError("Invalid file uploaded!")
                try:
                    await aiofiles.os.makedirs(os.path.dirname(download_path), exist_ok=True)
                except OSError as e:
                    if hasattr(e, "winerror") and e.winerror == 123:
                        raise FileError(f"The folderpath {os.path.dirname(file_path)} is unsupported!")
                    raise
                if await aiofiles.os.path.isdir(download_path):
                    raise FileError("Invalid file uploaded!")
                try:
                    async with aiofiles.open(download_path, "wb") as file:
                        req = drive_v3.files.get(
                            fileId=file_id,
                            pipe_to=file,
                            alt="media"
                        )
                        await self.send_req(aiogoogle, req)
                except OSError as e:
                    if e.errno == errno.EINVAL:
                        raise FileError(f"The filename {os.path.basename(file_path)} is unsupported!")
                    raise

                uploaded_file_paths.append(download_path)
                logger.info(f"Saved {file_path} to {download_path}")

                await embed_edit(
                    ctx, embgddone,
                    description_kwargs=dict(
                        filename=file_path, i=i, filecount=filecount
                    )
                )
                i += 1

        return [uploaded_file_paths]

gdapi: GDapi | None
if os.path.basename(argv[0]) == "bot.py":
    gdapi = GDapi()
else:
    gdapi = None

@tasks.loop(count=1, reconnect=False)
async def clean_GDrive() -> None:
    await gdapi.clear_drive()

@tasks.loop(hours=1, reconnect=False)
async def check_GDrive() -> None:
    if clean_GDrive.is_running():
        return

    cur_time = datetime.datetime.now()
    try:
        files = await gdapi.list_drive()
    except HTTPError as e:
        logger.error(f"GD-Error while listing drive (unexpected): {e}")
        print("Failed to check drive, check logs.")
        return

    for file in files:
        file_id = file["id"]

        created_time = parser.isoparse(file["createdTime"]) # RFC3339
        day_ahead = created_time + datetime.timedelta(days=1)

        if cur_time.date() >= day_ahead.date():
            try:
                await gdapi.delete_file(file_id)
            except HTTPError:
                pass

