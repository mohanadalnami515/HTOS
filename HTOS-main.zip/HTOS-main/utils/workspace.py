from __future__ import annotations
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from network.ftp_functions import FTPps

import os
import sys
import sqlite3
import shutil
import aiosqlite
import discord
import aiofiles
import aiofiles.os
import aiohttp
import asyncio
from dataclasses import dataclass
from ftplib import FTP, error_perm
from psnawp_api.core.psnawp_exceptions import PSNAWPNotFoundError, PSNAWPAuthenticationError

from network.exceptions import FTPError
from google_drive.exceptions import GDapiError
from utils.constants import (
    UPLOAD_DECRYPTED, UPLOAD_ENCRYPTED, DOWNLOAD_DECRYPTED, PNG_PATH, KEYSTONE_PATH, NPSSO_global,
    DOWNLOAD_ENCRYPTED, PARAM_PATH, STORED_SAVES_FOLDER, IP, PORT_FTP, MOUNT_LOCATION, PS_UPLOADDIR, MISC_TIMEOUT,
    DATABASENAME_THREADS, DATABASENAME_ACCIDS, DATABASENAME_BLACKLIST, BLACKLIST_MESSAGE, RANDOMSTRING_LENGTH, BASE_ERROR_MSG,
    logger, blacklist_logger, psnawp, verify_titleids
)
from utils.embeds import emb_il, embChannelError, retry_emb, blacklist_emb, gd_maintenance_emb, embe
from utils.extras import generate_random_string
from utils.type_helpers import uint64
from utils.instance_lock import INSTANCE_LOCK_global
from utils.exceptions import InstanceError, WorkspaceError

@dataclass
class WorkspaceOpt:
    ignore_startup: bool = False

def delete_folder_contents_ftp_BLOCKING(ftp: FTP, folder_path: str) -> None:
    """Blocking FTP function to delete folders, used in startup to cleanup."""
    try:
        ftp.cwd(folder_path)
        items9 = ftp.mlsd()

        for namew, attrs in items9:
            if namew in [".", ".."]:
                continue

            if attrs["type"] == "dir":
                delete_folder_contents_ftp_BLOCKING(ftp, namew)
            else:
                try:
                    ftp.delete(namew)
                except error_perm as e:
                    logger.error(f"Permission error for {namew}: {e}")

        ftp.cwd("..")
        ftp.rmd(folder_path)
        logger.info(f"Folder contents of '{folder_path}' deleted successfully.")
    except error_perm as e:
        logger.error(f"An error occurred: {e}")

def startup(opt: WorkspaceOpt, lite: bool = False):
    """Makes sure everything exists and cleans up unnecessary files, used when starting up bot."""
    if opt.ignore_startup:
        return

    FOLDERS = [
        UPLOAD_ENCRYPTED, UPLOAD_DECRYPTED, DOWNLOAD_ENCRYPTED, DOWNLOAD_DECRYPTED,
        PNG_PATH, PARAM_PATH, KEYSTONE_PATH, STORED_SAVES_FOLDER
    ]

    for path in FOLDERS:
        if not os.path.exists(path):
            try: os.makedirs(path)
            except:
                print(f"Can not create essential folders, make sure they are created!\n{', '.join(FOLDERS)}")
                sys.exit()
        else:
            if path != STORED_SAVES_FOLDER:
                shutil.rmtree(path)

                try: os.makedirs(path)
                except:
                    print(f"Can not create essential folders, make sure they are created!\n{', '.join(FOLDERS)}")
                    sys.exit()

    with FTP() as ftp:
        try:
            ftp.connect(IP, PORT_FTP, timeout=10)
            ftp.login()
            try:
                ftp.mkd(MOUNT_LOCATION)
                ftp.mkd(PS_UPLOADDIR)
            except: pass
            delete_folder_contents_ftp_BLOCKING(ftp, MOUNT_LOCATION)
            delete_folder_contents_ftp_BLOCKING(ftp, PS_UPLOADDIR)
            ftp.mkd(MOUNT_LOCATION)
            ftp.mkd(PS_UPLOADDIR)
            ftp.quit()
        except:
            pass

    verify_titleids()

    if lite:
        return

    try:
        conn = sqlite3.connect(DATABASENAME_THREADS)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS Threads (
                    disc_userid BLOB,
                    disc_threadid BLOB
            )
        """)
        conn.commit()
        cursor.close()
        conn.close()

        #######

        conn = sqlite3.connect(DATABASENAME_ACCIDS)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS Account_IDs (
                    disc_userid BLOB,
                    ps_accountid BLOB
            )
        """)
        conn.commit()
        cursor.close()
        conn.close()

        #######
        conn = sqlite3.connect(DATABASENAME_BLACKLIST)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS PS_Users (
                    account_id BLOB UNIQUE,
                    username TEXT UNIQUE,
                    reason TEXT
            )
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS Disc_Users (
                    user_id BLOB UNIQUE,
                    username TEXT UNIQUE,
                    reason TEXT
            )
        """)
        conn.commit()
        cursor.close()
        conn.close()
    except sqlite3.Error as e:
        print(f"Error creating databases: {e}\nExiting...")
        logger.error(f"Error creating databases: {e}")
        sys.exit()

async def cleanup(
          fInstance: FTPps,
          local_folders: list[str] | None,
          remote_savelist: list[str] | None,
          remote_mount_paths: list[str] | None
        ) -> None:
    """Used to cleanup after a command utilizing the ps4 (remote)."""
    if local_folders is not None and len(local_folders) > 0:
        for folderpath in local_folders:
            try:
                if await aiofiles.os.path.exists(folderpath):
                    shutil.rmtree(folderpath)
            except OSError as e:
                logger.error(f"Error accessing {folderpath} when cleaning up: {e}")

    if remote_savelist is not None and len(remote_savelist) > 0:
        try:
            async with asyncio.timeout(MISC_TIMEOUT):
                await fInstance.delete_list(PS_UPLOADDIR, remote_savelist)
        except TimeoutError:
            logger.info("Timed out!")
        except (FTPError, OSError) as e:
            logger.error(f"An error occurred when cleaning up (FTP): {e}")

    if remote_mount_paths is not None and len(remote_mount_paths) > 0:
        for mountlocation in remote_mount_paths[:]:
            try:
                async with asyncio.timeout(MISC_TIMEOUT):
                    await fInstance.delete_folder_contents(mountlocation)
                remote_mount_paths.remove(mountlocation)
            except TimeoutError:
                logger.info("Timed out!")
            except (FTPError, OSError) as e:
                logger.error(f"An error occurred when cleaning up (FTP): {e}")

async def cleanup_simple(clean_list: list[str] | None) -> None:
    """Used to cleanup after a command that does not utilize the ps4 (local only)."""
    if not clean_list:
        return
    for folderpath in clean_list:
        try:
            if await aiofiles.os.path.exists(folderpath):
                shutil.rmtree(folderpath)
        except OSError as e:
            logger.error(f"Error accessing {folderpath} when cleaning up (simple): {e}")

def init_workspace() -> tuple[str, str, str, str, str, str, str]:
    """Obtains the local paths for an user, used when initializing a command that needs the local filesystem."""
    randomString = generate_random_string(RANDOMSTRING_LENGTH)
    newUPLOAD_ENCRYPTED = os.path.join(UPLOAD_ENCRYPTED, randomString)
    newUPLOAD_DECRYPTED = os.path.join(UPLOAD_DECRYPTED, randomString)
    newDOWNLOAD_ENCRYPTED = os.path.join(DOWNLOAD_ENCRYPTED, randomString)
    newPNG_PATH = os.path.join(PNG_PATH, randomString)
    newPARAM_PATH = os.path.join(PARAM_PATH, randomString)
    newDOWNLOAD_DECRYPTED = os.path.join(DOWNLOAD_DECRYPTED, randomString)
    newKEYSTONE_PATH = os.path.join(KEYSTONE_PATH, randomString)

    return newUPLOAD_ENCRYPTED, newUPLOAD_DECRYPTED, newDOWNLOAD_ENCRYPTED, newPNG_PATH, newPARAM_PATH, newDOWNLOAD_DECRYPTED, newKEYSTONE_PATH

async def make_workspace(ctx: discord.ApplicationContext, workspaceList: list[str], thread_id: int, skip_gd_check: bool = False) -> None:
    """Used for checking if a command is being run in a valid thread."""
    await ctx.defer()

    threadId = uint64(thread_id, "big")

    try:
        async with aiosqlite.connect(DATABASENAME_THREADS) as db:
            cursor = await db.cursor()
            await cursor.execute("SELECT * FROM Threads WHERE disc_threadid = ?", (threadId.as_bytes,))

            row = await cursor.fetchone()
            if not row:
                await ctx.respond(embed=embChannelError)
                raise WorkspaceError("Invalid channel!")
    except aiosqlite.Error:
        await ctx.respond(embed=retry_emb)
        raise WorkspaceError("Please try again.")

    # check blacklist while we are at it
    search = await blacklist_check_db(ctx.author.id, None)
    if search[0]:
        blacklist_logger.info(f"{ctx.author.name} ({ctx.author.id}) used a command while blacklisted!")
        reason = search[1]
        emb = blacklist_emb.copy()
        if reason is not None:
            emb.description = reason
        await ctx.respond(embed=emb)
        raise WorkspaceError(BLACKLIST_MESSAGE)

    # check if there are available instance slots
    try:
        await INSTANCE_LOCK_global.acquire(ctx.author.id)
    except InstanceError as e:
        emb = emb_il.copy()
        emb.description = emb.description.format(error=e)
        await ctx.respond(embed=emb)
        raise WorkspaceError(e)

    # google drive check: are we currently deleting all files or do we need to delete all files
    from google_drive.gd_functions import gdapi
    if not skip_gd_check and gdapi.is_available():
        from google_drive.gd_functions import clean_GDrive

        if clean_GDrive.is_running():
            await INSTANCE_LOCK_global.release(ctx.author.id)
            await ctx.respond(embed=gd_maintenance_emb)
            raise WorkspaceError("Please try again!")
        try:
            gd_check = await gdapi.check_drive_storage()
        except GDapiError as e:
            await INSTANCE_LOCK_global.release(ctx.author.id)
            gd_emb = gd_maintenance_emb.copy()
            gd_emb.description = e
            await ctx.respond(embed=gd_emb)
            raise WorkspaceError("Please try again!")
        except Exception as e:
            await INSTANCE_LOCK_global.release(ctx.author.id)
            err_emb = embe.copy()
            err_emb.description = err_emb.description.format(error=BASE_ERROR_MSG)
            await ctx.respond(embed=err_emb)
            raise WorkspaceError("Please try again!")
        if not gd_check:
            try:
                clean_GDrive.start()
            except RuntimeError:
                pass
            await INSTANCE_LOCK_global.release(ctx.author.id)
            await ctx.respond(embed=gd_maintenance_emb)
            raise WorkspaceError("Please try again!")

    # passed
    for path in workspaceList:
        try:
            await aiofiles.os.makedirs(path)
        except OSError as e:
            logger.error(f"Error while creating folder {path}: {e}")
            await INSTANCE_LOCK_global.release(ctx.author.id)
            await ctx.respond(embed=retry_emb)
            raise WorkspaceError("Please try again.")
        except Exception as e:
            logger.error(f"Unexpected error while creating folder {path}: {e}")
            await INSTANCE_LOCK_global.release(ctx.author.id)
            await ctx.respond(embed=retry_emb)
            raise WorkspaceError("Please try again.")

def enumerate_files(files: list[str], rand_str: str) -> list[str]:
    """Adds a random string at the end of the filename for save pairs, used to make sure there is no overwriting remotely."""
    out = []
    for i in range(0, len(files), 2):
        path = files[i]
        base = os.path.basename(path).removesuffix(".bin")
        s = f"{base}_{rand_str}"
        out.append(s)
        out.append(s + ".bin")
    return out

async def get_savenames_from_bin_ext(path: str) -> list[str]:
    savenames = []
    saves = await aiofiles.os.listdir(path)

    for save in saves:
        base, ext = os.path.splitext(save)
        if ext != ".bin":
            continue
        if base in saves:
            savenames.append(base)
    return savenames

async def list_stored_saves() -> dict[str, dict[str, dict[str, str]]]:
    """Lists the saves in the stored folder, used in the quick resign command."""
    game_list = await aiofiles.os.listdir(STORED_SAVES_FOLDER)
    stored_saves = {}

    if len(game_list) == 0:
        raise WorkspaceError("NO STORED SAVES!")

    for game in game_list:
        gamepath = os.path.join(STORED_SAVES_FOLDER, game)

        if await aiofiles.os.path.isdir(gamepath):
            stored_saves[game] = {}

            game_regions = await aiofiles.os.listdir(gamepath)

            for region in game_regions:
                regionpath = os.path.join(STORED_SAVES_FOLDER, game, region)
                if await aiofiles.os.path.isdir(regionpath):
                    stored_saves[game][region] = {}

                    gamesaves = await aiofiles.os.listdir(regionpath)
                    for save in gamesaves:
                        savepath = os.path.join(STORED_SAVES_FOLDER, game, region, save)
                        if await aiofiles.os.path.isdir(savepath):
                            if len(await get_savenames_from_bin_ext(savepath)) > 0:
                                stored_saves[game][region][save] = savepath

    return stored_saves

async def write_threadid_db(disc_userid: int, thread_id: int) -> list[int]:
    """Used to write thread IDs into the db on behalf of a user, if an entry exists it will be overwritten."""
    delete_these = []
    userId = uint64(disc_userid, "big")
    threadId = uint64(thread_id, "big")

    try:
        async with aiosqlite.connect(DATABASENAME_THREADS) as db:
            cursor = await db.cursor()

            await cursor.execute("SELECT disc_threadid from Threads WHERE disc_userid = ?", (userId.as_bytes,)) # obtain thread id to delete from disc server, fetchall incase of any errors when deleting
            rows = await cursor.fetchall()

            await cursor.execute("DELETE FROM Threads WHERE disc_userid = ?", (userId.as_bytes,)) # delete all thread ids from a user in the database, limit to 1 thread per user
            await cursor.execute("INSERT INTO Threads (disc_userid, disc_threadid) VALUES (?, ?)", (userId.as_bytes, threadId.as_bytes,)) # finally, write
            await db.commit()
    except aiosqlite.Error as e:
        raise WorkspaceError(e)

    for thread_id in rows:
        threadId = uint64(thread_id[0], "big")
        delete_these.append(threadId.value)
    return delete_these

async def fetchall_threadid_db() -> dict[int, int]:
    db_dict = {}
    try:
        async with aiosqlite.connect(DATABASENAME_THREADS) as db:
            cursor = await db.cursor()

            await cursor.execute("SELECT disc_userid, disc_threadid FROM Threads")
            ids = await cursor.fetchall()
    except aiosqlite.Error as e:
        raise WorkspaceError(e)

    for user_id, thread_id in ids:
        userId = uint64(user_id, "big")
        threadId = uint64(thread_id, "big")

        db_dict[userId.value] = threadId.value
    return db_dict

async def delall_threadid_db(db_dict: dict[int, int]) -> None:
    try:
        async with aiosqlite.connect(DATABASENAME_THREADS) as db:
            cursor = await db.cursor()

            for user_id, thread_id in db_dict.items():
                userId = uint64(user_id, "big")
                threadId = uint64(thread_id, "big")

                await cursor.execute("DELETE FROM Threads WHERE disc_userid = ? AND disc_threadid = ?", (userId.as_bytes, threadId.as_bytes,))
            await db.commit()
    except aiosqlite.Error as e:
        raise WorkspaceError(e)

async def fetch_accountid_db(disc_userid: int) -> str | None:
    """Used to obtain an account ID stored in the db to user."""

    userId = uint64(disc_userid, "big")

    try:
        async with aiosqlite.connect(DATABASENAME_ACCIDS) as db:
            cursor = await db.cursor()

            await cursor.execute("SELECT ps_accountid FROM Account_IDs WHERE disc_userid = ?", (userId.as_bytes,))
            row = await cursor.fetchone()
    except aiosqlite.Error as e:
        raise WorkspaceError(e)

    if row:
        accid = uint64(row[0], "big")
        return accid.as_bytes.hex()
    else:
        return None

async def write_accountid_db(disc_userid: int, account_id: str) -> None:
    """Used to store the user's account ID in the db, removing the previously stored one."""

    accid = int(account_id, 16)
    accid = uint64(accid, "big")

    userId = uint64(disc_userid, "big")

    try:
        async with aiosqlite.connect(DATABASENAME_ACCIDS) as db:
            cursor = await db.cursor()

            await cursor.execute("DELETE FROM Account_IDs WHERE disc_userid = ?", (userId.as_bytes,)) # remove previously stored accid
            await cursor.execute("INSERT INTO Account_IDs (disc_userid, ps_accountid) VALUES (?, ?)", (userId.as_bytes, accid.as_bytes,))
            await db.commit()
    except aiosqlite.Error as e:
        logger.error(f"Could not write account ID to database: {e}")
        raise WorkspaceError("Failed to write!")

async def blacklist_write_db(disc_user: discord.User | None, account_id: str | None, reason: str | None) -> None:
    """Add entry to the blacklist db."""
    if disc_user is None and account_id is None:
        return

    try:
        async with aiosqlite.connect(DATABASENAME_BLACKLIST) as db:
            cursor = await db.cursor()

            if disc_user is not None:
                userId = uint64(disc_user.id, "big")

                await cursor.execute("INSERT OR IGNORE INTO Disc_Users (user_id, username, reason) VALUES (?, ?, ?)", (userId.as_bytes, disc_user.name, reason,))

            if account_id is not None:
                accid = int(account_id, 16)
                username = None
                if NPSSO_global.val:
                    try:
                        ps_user = psnawp.user(account_id=str(accid))
                        username = ps_user.online_id
                    except PSNAWPNotFoundError:
                        pass
                    except PSNAWPAuthenticationError:
                        NPSSO_global.val = ""
                accid = uint64(accid, "big")

                await cursor.execute("INSERT OR IGNORE INTO PS_Users (account_id, username, reason) VALUES (?, ?, ?)", (accid.as_bytes, username, reason,))

            await db.commit()
    except aiosqlite.Error as e:
        blacklist_logger.error(f"Could not write to blacklist database: {e}")
        raise WorkspaceError("DB FAIL!")

async def blacklist_check_db(disc_userid: int | None, account_id: str | None) -> tuple[bool, str | None]:
    """Check if value is blacklisted, only use argument, leave other to None."""
    assert (disc_userid is None) != (account_id is None)

    try:
        async with aiosqlite.connect(DATABASENAME_BLACKLIST) as db:
            cursor = await db.cursor()

            if disc_userid is not None:
                # userid provided
                val = uint64(disc_userid, "big")
                await cursor.execute("SELECT reason FROM Disc_Users WHERE user_id = ?", (val.as_bytes,))
                res = await cursor.fetchone()
                if res:
                    reason = res[0]
                    return True, reason

            else:
                # account_id provided
                val = int(account_id, 16)
                val = uint64(val, "big")
                await cursor.execute("SELECT reason FROM PS_Users WHERE account_id = ?", (val.as_bytes,))
                res = await cursor.fetchone()
                if res:
                    reason = res[0]
                    return True, reason
    except aiosqlite.Error as e:
        blacklist_logger.error(f"Could check blacklist database: {e}")

    return False, None

async def blacklist_del_db(disc_userid: int | None, account_id: str | None) -> None:
    """Delete entry in blacklist db."""
    assert disc_userid is not None or account_id is not None

    try:
        async with aiosqlite.connect(DATABASENAME_BLACKLIST) as db:
            cursor = await db.cursor()

            if disc_userid is not None:
                # userid provided
                val = uint64(disc_userid, "big")
                await cursor.execute("DELETE FROM Disc_Users WHERE user_id = ?", (val.as_bytes,))

            if account_id is not None:
                # account_id provided
                val = int(account_id, 16)
                val = uint64(val, "big")
                await cursor.execute("DELETE FROM PS_Users WHERE account_id = ?", (val.as_bytes,))

            await db.commit()
    except aiosqlite.Error as e:
        blacklist_logger.error(f"Could not remove entry from blacklist database: {e}")
        raise WorkspaceError("DB FAIL!")

async def blacklist_delall_db() -> None:
    """Delete all entries in blacklist db."""
    try:
        async with aiosqlite.connect(DATABASENAME_BLACKLIST) as db:
            cursor = await db.cursor()

            await cursor.execute("DELETE FROM Disc_Users")
            await cursor.execute("DELETE FROM PS_Users")

            await db.commit()
    except aiosqlite.Error as e:
        blacklist_logger.error(f"Could not delete all entries in blacklist database: {e}")
        raise WorkspaceError("DB FAIL!")

async def blacklist_fetchall_db() -> dict[str, list[dict[str | None, str]] | list[dict[str | None, int]]]:
    """Obtain all entries inside the blacklist db."""
    entries = {"PlayStation account IDs": [], "Discord user IDs": []}

    accids = userids = []

    try:
        async with aiosqlite.connect(DATABASENAME_BLACKLIST) as db:
            cursor = await db.cursor()

            await cursor.execute("SELECT account_id, username, reason FROM PS_Users")
            accids = await cursor.fetchall()

            await cursor.execute("SELECT user_id, username, reason FROM Disc_Users")
            userids = await cursor.fetchall()
    except aiosqlite.Error as e:
        blacklist_logger.error(f"Could not fetch all blacklist database entries: {e}")
        raise WorkspaceError("DB FAIL!")

    for accid, username, reason in accids:
        accid = uint64(accid, "big")
        entry = {"0x" + hex(accid.value)[2:].zfill(16): [username, reason]}
        entries["PlayStation account IDs"].append(entry)

    for userid, username, reason in userids:
        userid = uint64(userid, "big")

        entry = {userid.value: [username, reason]}
        entries["Discord user IDs"].append(entry)
    return entries

def semver_to_num(ver: str | int) -> int:
    if isinstance(ver, int):
        return ver

    ver = ver[1:].split(".")
    ver = int("".join(ver))
    return ver

async def check_version() -> str:
    from utils.constants import VERSION

    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
            async with session.get("https://api.github.com/repos/hzhreal/HTOS/releases/latest") as resp:
                content = await resp.json()
                latest_ver = content.get("tag_name", 0)
    except:
        print("Failed to get latest version through Github.\n")
        return ""

    latest_ver_num = semver_to_num(latest_ver)
    cur_ver_num = semver_to_num(VERSION)

    if cur_ver_num < latest_ver_num:
        print("Attention: You are running an outdated version of HTOS. Please update to the latest version to ensure security, performance, and access to new features.")
        print(f"Your version: {VERSION}")
        print(f"Latest version: {latest_ver}")
        print("\n")
        return "Outdated"
    elif cur_ver_num > latest_ver_num:
        print("Attention: You are running a version of HTOS that is newer than the latest release. Please report any bugs you may encounter.")
        print(f"Your version: {VERSION}")
        print(f"Latest version: {latest_ver}")
        print("\n")
        return "Experimental"
    else:
        print("You are running the latest version of HTOS.")
        print(f"Your version: {VERSION}")
        print(f"Latest version: {latest_ver}")
        print("\n")
        return "Stable"

